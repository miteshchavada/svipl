<?php

/* ::common.html.twig */
class __TwigTemplate_cd2aaca57019bba785d0efaa3442f5ab5aa07485623e58fbfdf38be30eebcda6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 15
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 35
        echo "    </head>
    <body id=\"page2\">
        <div class=\"body1\">
            <div class=\"body2\">
                <div class=\"body5\">
                    <div class=\"main zerogrid\">
                        <!-- header -->
                        ";
        // line 42
        if ($this->env->getExtension('security')->isGranted("ROLE_USER")) {
            // line 43
            echo "                        <a href=\"";
            echo $this->env->getExtension('routing')->getPath("agentlogout");
            echo "\">
                            <i class=\"fa fa-sign-out fa-fw\"></i> Logout</a>    
                        <i class=\"fa fa-user fa-fw\"></i>";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "user"), "username")), "FOSUserBundle"), "html", null, true);
            echo " <i class=\"fa fa-caret-down\"></i>
                        ";
        } else {
            // line 47
            echo "                            <a class=\"navbar-brand\" href=\"";
            echo $this->env->getExtension('routing')->getPath("agentlogin");
            echo "\">Login</a>
                        ";
        }
        // line 49
        echo "                        <header>
                            <div class=\"wrapper rơw\">
                                <h1><a href=\"";
        // line 51
        echo $this->env->getExtension('routing')->getPath("acme_home");
        echo "\" id=\"logo\"><img src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/images/logo.png"), "html", null, true);
        echo "\" /></a></h1>
                                <nav>
                                    <ul id=\"menu\">
                                        ";
        // line 54
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "acme_home")) {
            // line 55
            echo "                                            <li id=\"nav1\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        } else {
            // line 57
            echo "                                            <li id=\"nav1\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        }
        // line 59
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "news")) {
            // line 60
            echo "                                            <li id=\"nav2\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        } else {
            // line 62
            echo "                                            <li id=\"nav2\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        }
        // line 64
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "services")) {
            // line 65
            echo "                                            <li id=\"nav3\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        } else {
            // line 67
            echo "                                            <li id=\"nav3\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        }
        // line 69
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "products")) {
            // line 70
            echo "                                            <li id=\"nav4\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        } else {
            // line 72
            echo "                                            <li id=\"nav4\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        }
        // line 74
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "contact")) {
            // line 75
            echo "                                            <li id=\"nav5\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        } else {
            // line 77
            echo "                                            <li id=\"nav5\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        }
        // line 78
        echo "    
                                    </ul>
                                </nav>
                            </div>
                        </header>
                        <!-- header end-->
                    </div>
                </div>
            </div>
        </div>
    ";
        // line 88
        $this->displayBlock('body', $context, $blocks);
        // line 89
        echo "</body>
</html>
";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        echo "Test Application";
    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 9
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/reset.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/layout.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/zerogrid.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/responsive.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        ";
    }

    // line 15
    public function block_javascripts($context, array $blocks = array())
    {
        // line 16
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jquery-1.6.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-yui.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-replace.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_400.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_700.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/tabs.js"), "html", null, true);
        echo "\"></script> 
            <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/css3-mediaqueries.js"), "html", null, true);
        echo "\"></script> 
            <!--[if lt IE 9]>
                  <script type=\"text/javascript\" src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/html5.js"), "html", null, true);
        echo "\"></script>
                  <style type=\"text/css\">
                          .bg{ behavior: url(js/PIE.htc); }
                  </style>
            <![endif]-->
            <!--[if lt IE 7]>
                    <div style=' clear: both; text-align:center; position: relative;'>
                            <a href=\"http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode\"><img src=\"http://www.theie6countdown.com/images/upgrade.jpg\" border=\"0\"  alt=\"\" /></a>
                    </div>
            <![endif]-->
        ";
    }

    // line 88
    public function block_body($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::common.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  253 => 88,  238 => 24,  233 => 22,  229 => 21,  225 => 20,  221 => 19,  217 => 18,  213 => 17,  208 => 16,  205 => 15,  199 => 13,  195 => 12,  191 => 11,  187 => 10,  182 => 9,  179 => 8,  173 => 6,  167 => 89,  165 => 88,  153 => 78,  147 => 77,  141 => 75,  138 => 74,  132 => 72,  126 => 70,  123 => 69,  117 => 67,  111 => 65,  108 => 64,  102 => 62,  96 => 60,  93 => 59,  87 => 57,  81 => 55,  79 => 54,  71 => 51,  67 => 49,  61 => 47,  56 => 45,  50 => 43,  48 => 42,  39 => 35,  36 => 15,  34 => 8,  29 => 6,  23 => 2,);
    }
}
