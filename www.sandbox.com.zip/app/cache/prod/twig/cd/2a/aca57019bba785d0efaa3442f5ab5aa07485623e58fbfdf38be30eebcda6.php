<?php

/* ::common.html.twig */
class __TwigTemplate_cd2aaca57019bba785d0efaa3442f5ab5aa07485623e58fbfdf38be30eebcda6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 15
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 35
        echo "    </head>
    <body id=\"page2\">
        <div class=\"body1\">
            <div class=\"body2\">
                <div class=\"body5\">
                    <div class=\"main zerogrid\">
                        <!-- header -->
                        <header>
                            <div class=\"wrapper rơw\">
                                <h1><a href=\"";
        // line 44
        echo $this->env->getExtension('routing')->getPath("acme_home");
        echo "\" id=\"logo\"><img src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/images/logo.png"), "html", null, true);
        echo "\" /></a></h1>
                                <nav>
                                    <ul id=\"menu\">
                                        ";
        // line 47
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "acme_home")) {
            // line 48
            echo "                                            <li id=\"nav1\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        } else {
            // line 50
            echo "                                            <li id=\"nav1\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        }
        // line 52
        echo "                                            ";
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "news")) {
            // line 53
            echo "                                            <li id=\"nav2\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        } else {
            // line 55
            echo "                                            <li id=\"nav2\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        }
        // line 57
        echo "                                            ";
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "services")) {
            // line 58
            echo "                                            <li id=\"nav3\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        } else {
            // line 60
            echo "                                            <li id=\"nav3\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        }
        // line 62
        echo "                                            ";
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "products")) {
            // line 63
            echo "                                            <li id=\"nav4\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        } else {
            // line 65
            echo "                                            <li id=\"nav4\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        }
        // line 67
        echo "                                            ";
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "contact")) {
            // line 68
            echo "                                            <li id=\"nav5\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        } else {
            // line 70
            echo "                                            <li id=\"nav5\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        }
        // line 71
        echo "    
                                    </ul>
                                </nav>
                            </div>
                        </header>
                        <!-- header end-->
                    </div>
                </div>
            </div>
        </div>
    ";
        // line 81
        $this->displayBlock('body', $context, $blocks);
        // line 82
        echo "</body>
</html>
";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        echo "Test Application";
    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 9
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/reset.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/layout.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/zerogrid.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/responsive.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        ";
    }

    // line 15
    public function block_javascripts($context, array $blocks = array())
    {
        // line 16
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jquery-1.6.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-yui.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-replace.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_400.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_700.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/tabs.js"), "html", null, true);
        echo "\"></script> 
            <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/css3-mediaqueries.js"), "html", null, true);
        echo "\"></script> 
            <!--[if lt IE 9]>
                  <script type=\"text/javascript\" src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/html5.js"), "html", null, true);
        echo "\"></script>
                  <style type=\"text/css\">
                          .bg{ behavior: url(js/PIE.htc); }
                  </style>
            <![endif]-->
            <!--[if lt IE 7]>
                    <div style=' clear: both; text-align:center; position: relative;'>
                            <a href=\"http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode\"><img src=\"http://www.theie6countdown.com/images/upgrade.jpg\" border=\"0\"  alt=\"\" /></a>
                    </div>
            <![endif]-->
        ";
    }

    // line 81
    public function block_body($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::common.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  217 => 22,  213 => 21,  209 => 20,  205 => 19,  175 => 11,  73 => 52,  74 => 14,  311 => 116,  270 => 26,  266 => 25,  262 => 24,  258 => 23,  254 => 22,  250 => 21,  246 => 20,  242 => 19,  238 => 18,  233 => 17,  230 => 16,  220 => 13,  216 => 12,  212 => 11,  203 => 9,  172 => 106,  144 => 94,  141 => 93,  82 => 15,  176 => 49,  153 => 35,  148 => 34,  125 => 68,  68 => 12,  145 => 48,  86 => 21,  83 => 55,  206 => 201,  200 => 8,  188 => 117,  179 => 12,  177 => 184,  174 => 183,  159 => 86,  151 => 82,  135 => 80,  99 => 60,  165 => 101,  139 => 81,  126 => 43,  95 => 36,  91 => 31,  87 => 34,  23 => 2,  128 => 27,  116 => 36,  79 => 17,  61 => 48,  20 => 1,  42 => 10,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 29,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 18,  143 => 46,  138 => 30,  134 => 41,  131 => 70,  122 => 38,  117 => 36,  108 => 81,  102 => 28,  92 => 76,  84 => 14,  72 => 70,  48 => 12,  35 => 5,  29 => 6,  69 => 13,  54 => 12,  51 => 21,  31 => 3,  312 => 96,  308 => 94,  293 => 40,  285 => 90,  281 => 88,  277 => 86,  274 => 27,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 81,  204 => 69,  198 => 65,  194 => 6,  150 => 98,  147 => 83,  127 => 41,  112 => 19,  96 => 33,  76 => 71,  71 => 16,  39 => 35,  110 => 20,  89 => 57,  65 => 23,  63 => 12,  58 => 47,  34 => 8,  55 => 12,  26 => 11,  24 => 6,  43 => 7,  114 => 83,  109 => 63,  106 => 18,  101 => 30,  85 => 25,  77 => 53,  67 => 50,  28 => 2,  227 => 92,  224 => 14,  221 => 90,  207 => 70,  197 => 17,  195 => 65,  192 => 16,  189 => 15,  186 => 116,  181 => 67,  178 => 61,  173 => 58,  162 => 58,  158 => 56,  155 => 99,  152 => 40,  142 => 32,  136 => 90,  133 => 29,  130 => 88,  120 => 85,  105 => 62,  100 => 37,  75 => 23,  60 => 66,  53 => 10,  57 => 65,  50 => 44,  47 => 11,  38 => 8,  25 => 3,  19 => 1,  98 => 17,  88 => 75,  80 => 15,  78 => 25,  46 => 12,  44 => 8,  40 => 16,  36 => 15,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 24,  215 => 204,  211 => 203,  208 => 10,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 13,  180 => 50,  171 => 10,  166 => 9,  163 => 8,  160 => 49,  157 => 6,  149 => 81,  146 => 41,  140 => 52,  137 => 71,  129 => 44,  124 => 26,  121 => 67,  118 => 22,  115 => 65,  111 => 32,  107 => 32,  104 => 80,  97 => 34,  93 => 58,  90 => 16,  81 => 25,  70 => 18,  66 => 68,  62 => 11,  59 => 15,  56 => 9,  52 => 11,  49 => 62,  45 => 18,  41 => 5,  37 => 5,  33 => 3,  30 => 1,);
    }
}
