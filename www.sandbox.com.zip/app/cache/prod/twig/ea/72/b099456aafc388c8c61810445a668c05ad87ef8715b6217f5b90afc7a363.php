<?php

/* ::front.html.twig */
class __TwigTemplate_ea72b099456aafc388c8c61810445a668c05ad87ef8715b6217f5b90afc7a363 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 54
        echo "    </head>
    <body id=\"page1\">
        <div id=\"sidebar\">
            <div class=\"body1\">
                <div class=\"body2\">
                    <div class=\"main zerogrid\">
                        ";
        // line 60
        if ($this->env->getExtension('security')->isGranted("ROLE_USER")) {
            // line 61
            echo "                        <a href=\"";
            echo $this->env->getExtension('routing')->getPath("agentlogout");
            echo "\" id=\"logout\">
                            <i class=\"fa fa-sign-out fa-fw\"></i> Logout</a>    
                        <i class=\"fa fa-user fa-fw\"></i>";
            // line 63
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute($this->getContext($context, "app"), "user"), "username")), "FOSUserBundle"), "html", null, true);
            echo " <i class=\"fa fa-caret-down\"></i>
                        ";
        } else {
            // line 65
            echo "                            <a class=\"navbar-brand\" href=\"";
            echo $this->env->getExtension('routing')->getPath("agentlogin");
            echo "\">Login</a>
                        ";
        }
        // line 67
        echo "                        
                        <header>
                            <div class=\"wrapper row\">
                                <h1><a href=\"";
        // line 70
        echo $this->env->getExtension('routing')->getPath("acme_home");
        echo "\" id=\"logo\"><img src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/images/logo.png"), "html", null, true);
        echo "\" /></a></h1>
                                <nav>
                                    <ul id=\"menu\">
                                        ";
        // line 73
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "acme_home")) {
            // line 74
            echo "                                            <li id=\"nav1\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        } else {
            // line 76
            echo "                                            <li id=\"nav1\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        }
        // line 78
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "news")) {
            // line 79
            echo "                                            <li id=\"nav2\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        } else {
            // line 81
            echo "                                            <li id=\"nav2\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        }
        // line 83
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "services")) {
            // line 84
            echo "                                            <li id=\"nav3\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        } else {
            // line 86
            echo "                                            <li id=\"nav3\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        }
        // line 88
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "products")) {
            // line 89
            echo "                                            <li id=\"nav4\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        } else {
            // line 91
            echo "                                            <li id=\"nav4\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        }
        // line 93
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "contact")) {
            // line 94
            echo "                                            <li id=\"nav5\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        } else {
            // line 96
            echo "                                            <li id=\"nav5\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        }
        // line 98
        echo "                                    </ul>
                                </nav>
                            </div>
                            ";
        // line 101
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "acme_home")) {
            // line 102
            echo "                                <div class=\"wrapper row\">\t\t\t\t\t\t\t
                                    <div class=\"slider\">\t\t\t\t\t\t\t
                                        <div class=\"rslides_container\">
                                            <ul class=\"rslides\" id=\"slider\">
                                                ";
            // line 106
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getContext($context, "images"));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                // line 107
                echo "                                                    <li><img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/", 1 => $this->getAttribute($this->getContext($context, "image"), "image")))), "html", null, true);
                echo "\" alt=\"\"></li>
                                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 109
            echo "                                            </ul>
                                        </div>
                                    </div>\t\t\t\t\t\t\t
                                </div>
                            ";
        } else {
            // line 114
            echo "                                <div class=\"wrapper row\">
                                    <div class=\"slider\">
                                    </div>
                                </div>
                            ";
        }
        // line 119
        echo "                        </header>
                    </div>
                </div>
            </div>
        </div>
    ";
        // line 124
        $this->displayBlock('body', $context, $blocks);
        // line 125
        echo "</body>
</html>
";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        echo "Test Application";
    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 9
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/reset.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/layout.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/zerogrid.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/responsive.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/responsiveslides.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        ";
    }

    // line 16
    public function block_javascripts($context, array $blocks = array())
    {
        // line 17
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jquery-1.6.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-yui.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-replace.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_400.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_700.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jquery.easing.1.3.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/tms-0.3.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/tms_presets.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jcarousellite.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/script.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/css3-mediaqueries.js"), "html", null, true);
        echo "\"></script>
            <!--[if lt IE 9]>
                  <script type=\"text/javascript\" src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/html5.js"), "html", null, true);
        echo "\"></script>
                  <style type=\"text/css\">
                          .bg{ behavior: url(js/PIE.htc); }
                  </style>
            <![endif]-->
            <!--[if lt IE 7]>
                    <div style=' clear: both; text-align:center; position: relative;'>
                            <a href=\"http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode\"><img src=\"http://www.theie6countdown.com/images/upgrade.jpg\" border=\"0\"  alt=\"\" /></a>
                    </div>
            <![endif]-->

            <script src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/responsiveslides.js"), "html", null, true);
        echo "\"></script>
            <script>
                \$(function () {
                    \$(\"#slider\").responsiveSlides({
                        auto: true,
                        pager: false,
                        nav: true,
                        speed: 500,
                        maxwidth: 960,
                        namespace: \"centered-btns\"
                    });
                });
            </script>
        ";
    }

    // line 124
    public function block_body($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::front.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  325 => 124,  307 => 40,  293 => 29,  288 => 27,  284 => 26,  280 => 25,  276 => 24,  272 => 23,  268 => 22,  264 => 21,  260 => 20,  256 => 19,  252 => 18,  247 => 17,  244 => 16,  238 => 14,  234 => 13,  230 => 12,  226 => 11,  222 => 10,  217 => 9,  214 => 8,  208 => 6,  202 => 125,  200 => 124,  193 => 119,  186 => 114,  179 => 109,  170 => 107,  166 => 106,  160 => 102,  158 => 101,  153 => 98,  147 => 96,  141 => 94,  138 => 93,  132 => 91,  126 => 89,  123 => 88,  117 => 86,  111 => 84,  108 => 83,  102 => 81,  96 => 79,  93 => 78,  87 => 76,  81 => 74,  79 => 73,  71 => 70,  66 => 67,  60 => 65,  55 => 63,  49 => 61,  47 => 60,  39 => 54,  36 => 16,  34 => 8,  29 => 6,  23 => 2,);
    }
}
