<?php

/* ::front.html.twig */
class __TwigTemplate_ea72b099456aafc388c8c61810445a668c05ad87ef8715b6217f5b90afc7a363 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 54
        echo "    </head>
    <body id=\"page1\">
        <div id=\"sidebar\">
            <div class=\"body1\">
                <div class=\"body2\">
                    <div class=\"main zerogrid\">
                        <header>
                            <div class=\"wrapper row\">
                                <h1><a href=\"";
        // line 62
        echo $this->env->getExtension('routing')->getPath("acme_home");
        echo "\" id=\"logo\"><img src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/images/logo.png"), "html", null, true);
        echo "\" /></a></h1>
                                <nav>
                                    <ul id=\"menu\">
                                        ";
        // line 65
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "acme_home")) {
            // line 66
            echo "                                            <li id=\"nav1\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        } else {
            // line 68
            echo "                                            <li id=\"nav1\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        }
        // line 70
        echo "                                            ";
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "news")) {
            // line 71
            echo "                                            <li id=\"nav2\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        } else {
            // line 73
            echo "                                            <li id=\"nav2\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        }
        // line 75
        echo "                                            ";
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "services")) {
            // line 76
            echo "                                            <li id=\"nav3\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        } else {
            // line 78
            echo "                                            <li id=\"nav3\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        }
        // line 80
        echo "                                            ";
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "products")) {
            // line 81
            echo "                                            <li id=\"nav4\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        } else {
            // line 83
            echo "                                            <li id=\"nav4\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        }
        // line 85
        echo "                                            ";
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "contact")) {
            // line 86
            echo "                                            <li id=\"nav5\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        } else {
            // line 88
            echo "                                            <li id=\"nav5\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        }
        // line 90
        echo "                                    </ul>
                                </nav>
                            </div>
                            ";
        // line 93
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "acme_home")) {
            // line 94
            echo "                                <div class=\"wrapper row\">\t\t\t\t\t\t\t
                                    <div class=\"slider\">\t\t\t\t\t\t\t
                                        <div class=\"rslides_container\">
                                            <ul class=\"rslides\" id=\"slider\">
                                                ";
            // line 98
            if (isset($context["images"])) { $_images_ = $context["images"]; } else { $_images_ = null; }
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($_images_);
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                // line 99
                echo "                                                    <li><img src=\"";
                if (isset($context["image"])) { $_image_ = $context["image"]; } else { $_image_ = null; }
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/", 1 => $this->getAttribute($_image_, "image")))), "html", null, true);
                echo "\" alt=\"\"></li>
                                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 101
            echo "                                            </ul>
                                        </div>
                                    </div>\t\t\t\t\t\t\t
                                </div>
                            ";
        } else {
            // line 106
            echo "                                <div class=\"wrapper row\">
                                    <div class=\"slider\">
                                    </div>
                                </div>
                            ";
        }
        // line 111
        echo "                        </header>
                    </div>
                </div>
            </div>
        </div>
    ";
        // line 116
        $this->displayBlock('body', $context, $blocks);
        // line 117
        echo "</body>
</html>
";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        echo "Test Application";
    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 9
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/reset.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/layout.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/zerogrid.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/responsive.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/responsiveslides.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        ";
    }

    // line 16
    public function block_javascripts($context, array $blocks = array())
    {
        // line 17
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jquery-1.6.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-yui.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-replace.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_400.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_700.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jquery.easing.1.3.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/tms-0.3.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/tms_presets.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jcarousellite.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/script.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/css3-mediaqueries.js"), "html", null, true);
        echo "\"></script>
            <!--[if lt IE 9]>
                  <script type=\"text/javascript\" src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/html5.js"), "html", null, true);
        echo "\"></script>
                  <style type=\"text/css\">
                          .bg{ behavior: url(js/PIE.htc); }
                  </style>
            <![endif]-->
            <!--[if lt IE 7]>
                    <div style=' clear: both; text-align:center; position: relative;'>
                            <a href=\"http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode\"><img src=\"http://www.theie6countdown.com/images/upgrade.jpg\" border=\"0\"  alt=\"\" /></a>
                    </div>
            <![endif]-->

            <script src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/responsiveslides.js"), "html", null, true);
        echo "\"></script>
            <script>
                \$(function () {
                    \$(\"#slider\").responsiveSlides({
                        auto: true,
                        pager: false,
                        nav: true,
                        speed: 500,
                        maxwidth: 960,
                        namespace: \"centered-btns\"
                    });
                });
            </script>
        ";
    }

    // line 116
    public function block_body($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::front.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  311 => 116,  270 => 26,  266 => 25,  262 => 24,  258 => 23,  254 => 22,  250 => 21,  246 => 20,  242 => 19,  238 => 18,  233 => 17,  230 => 16,  220 => 13,  216 => 12,  212 => 11,  203 => 9,  172 => 106,  144 => 94,  141 => 93,  82 => 73,  176 => 49,  153 => 35,  148 => 34,  125 => 23,  68 => 12,  145 => 48,  86 => 21,  83 => 20,  206 => 201,  200 => 8,  188 => 117,  179 => 111,  177 => 184,  174 => 183,  159 => 86,  151 => 50,  135 => 80,  99 => 59,  165 => 101,  139 => 81,  126 => 43,  95 => 36,  91 => 31,  87 => 34,  23 => 2,  128 => 39,  116 => 36,  79 => 17,  61 => 17,  20 => 1,  42 => 10,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 29,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 66,  143 => 46,  138 => 30,  134 => 41,  131 => 42,  122 => 38,  117 => 36,  108 => 81,  102 => 28,  92 => 76,  84 => 14,  72 => 70,  48 => 12,  35 => 5,  29 => 6,  69 => 33,  54 => 12,  51 => 21,  31 => 3,  312 => 96,  308 => 94,  293 => 40,  285 => 90,  281 => 88,  277 => 86,  274 => 27,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 73,  204 => 69,  198 => 65,  194 => 6,  150 => 98,  147 => 83,  127 => 41,  112 => 19,  96 => 33,  76 => 71,  71 => 16,  39 => 54,  110 => 20,  89 => 16,  65 => 23,  63 => 12,  58 => 13,  34 => 8,  55 => 12,  26 => 11,  24 => 6,  43 => 7,  114 => 83,  109 => 63,  106 => 18,  101 => 30,  85 => 25,  77 => 12,  67 => 17,  28 => 2,  227 => 92,  224 => 14,  221 => 90,  207 => 70,  197 => 74,  195 => 65,  192 => 72,  189 => 61,  186 => 116,  181 => 67,  178 => 61,  173 => 58,  162 => 58,  158 => 56,  155 => 99,  152 => 40,  142 => 32,  136 => 90,  133 => 29,  130 => 88,  120 => 85,  105 => 38,  100 => 37,  75 => 23,  60 => 66,  53 => 10,  57 => 65,  50 => 7,  47 => 11,  38 => 8,  25 => 3,  19 => 1,  98 => 78,  88 => 75,  80 => 15,  78 => 25,  46 => 12,  44 => 8,  40 => 16,  36 => 16,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 76,  215 => 204,  211 => 203,  208 => 10,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 62,  180 => 50,  171 => 54,  166 => 51,  163 => 38,  160 => 49,  157 => 48,  149 => 48,  146 => 41,  140 => 52,  137 => 44,  129 => 44,  124 => 86,  121 => 42,  118 => 41,  115 => 21,  111 => 32,  107 => 32,  104 => 80,  97 => 34,  93 => 32,  90 => 35,  81 => 25,  70 => 18,  66 => 68,  62 => 11,  59 => 15,  56 => 9,  52 => 11,  49 => 62,  45 => 18,  41 => 5,  37 => 5,  33 => 3,  30 => 1,);
    }
}
