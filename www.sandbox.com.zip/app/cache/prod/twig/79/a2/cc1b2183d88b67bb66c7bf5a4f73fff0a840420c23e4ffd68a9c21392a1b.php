<?php

/* AcmeImageBundle:Default:index.html.twig */
class __TwigTemplate_79a2cc1b2183d88b67bb66c7bf5a4f73fff0a840420c23e4ffd68a9c21392a1b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        $this->displayBlock('content', $context, $blocks);
    }

    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <h1 class=\"page-header\">Slider Images</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <div class=\"panel panel-default\">
                        <div class=\"panel-heading\">
                            Slider Image List
\t\t\t\t<div style=\"float:right; margin-top:-15px;\" class=\"panel-heading\"><a href=\"add\"><button type=\"button\" class=\"btn btn-primary btn-sm\">Add Product</button></a></div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class=\"panel-body\">
                            <div class=\"table-responsive\">
                                <table class=\"table table-striped table-bordered table-hover\" id=\"dataTables-example1\">
                                    <thead>
                                        <tr>
                                            <th>Serial No</th>
                                            <th>Name</th>
                                            <th>Created At</th>
                                            <th>Updated At</th>
                                            <th>Operations</th>
                                        </tr>
                                    </thead>
                                    <tbody>
\t\t\t\t\t";
        // line 33
        if (isset($context["image"])) { $_image_ = $context["image"]; } else { $_image_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_image_);
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["im"]) {
            // line 34
            echo "\t\t\t\t\t<tr class=\"gradeA\">
\t\t\t\t\t    <td>";
            // line 35
            if (isset($context["loop"])) { $_loop_ = $context["loop"]; } else { $_loop_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_loop_, "index"), "html", null, true);
            echo "</td>
\t\t\t\t\t    <td><img src=\"";
            // line 36
            if (isset($context["im"])) { $_im_ = $context["im"]; } else { $_im_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/", 1 => $this->getAttribute($_im_, "image")))), "html", null, true);
            echo "\" style=\"width:80px; height: 50px;\" /></td>
\t\t\t\t\t    <td>";
            // line 37
            if (isset($context["im"])) { $_im_ = $context["im"]; } else { $_im_ = null; }
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($_im_, "createdAt")), "html", null, true);
            echo "</td>
\t\t\t\t\t    <td>";
            // line 38
            if (isset($context["im"])) { $_im_ = $context["im"]; } else { $_im_ = null; }
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($_im_, "updatedAt")), "html", null, true);
            echo "</td>    
\t\t\t\t\t    <td><a href=\"edit?id=";
            // line 39
            if (isset($context["im"])) { $_im_ = $context["im"]; } else { $_im_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_im_, "id"), "html", null, true);
            echo "\" class=\"btn btn-primary\">edit</a>
\t\t\t\t\t    <a href=\"delete?id=";
            // line 40
            if (isset($context["im"])) { $_im_ = $context["im"]; } else { $_im_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_im_, "id"), "html", null, true);
            echo "\" onclick=\"return confirm('are sure delete?')\" class=\"btn btn-danger\">delete</a></td>
\t\t\t\t\t</tr>
\t\t\t\t\t";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['im'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "\t\t\t\t   </tbody>
\t\t\t\t</tr>
\t\t\t\t</table>
\t\t\t   </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            <!-- /.row -->
";
    }

    public function getTemplateName()
    {
        return "AcmeImageBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 48,  86 => 21,  83 => 20,  206 => 201,  200 => 198,  188 => 192,  179 => 185,  177 => 184,  174 => 183,  159 => 86,  151 => 50,  135 => 80,  99 => 59,  165 => 51,  139 => 81,  126 => 43,  95 => 36,  91 => 31,  87 => 34,  23 => 3,  128 => 39,  116 => 36,  79 => 17,  61 => 14,  20 => 1,  42 => 10,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 78,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 66,  143 => 46,  138 => 44,  134 => 41,  131 => 42,  122 => 38,  117 => 36,  108 => 31,  102 => 28,  92 => 23,  84 => 31,  72 => 15,  48 => 11,  35 => 5,  29 => 2,  69 => 33,  54 => 15,  51 => 21,  31 => 4,  312 => 96,  308 => 94,  293 => 92,  285 => 90,  281 => 88,  277 => 86,  274 => 85,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 73,  204 => 69,  198 => 65,  194 => 195,  150 => 54,  147 => 83,  127 => 41,  112 => 19,  96 => 33,  76 => 17,  71 => 16,  39 => 4,  110 => 39,  89 => 16,  65 => 23,  63 => 12,  58 => 13,  34 => 4,  55 => 12,  26 => 11,  24 => 6,  43 => 7,  114 => 33,  109 => 63,  106 => 29,  101 => 30,  85 => 28,  77 => 12,  67 => 19,  28 => 3,  227 => 92,  224 => 91,  221 => 90,  207 => 70,  197 => 74,  195 => 65,  192 => 72,  189 => 61,  186 => 60,  181 => 67,  178 => 61,  173 => 58,  162 => 58,  158 => 56,  155 => 85,  152 => 40,  142 => 52,  136 => 44,  133 => 43,  130 => 42,  120 => 35,  105 => 38,  100 => 37,  75 => 23,  60 => 12,  53 => 10,  57 => 24,  50 => 7,  47 => 8,  38 => 4,  25 => 3,  19 => 1,  98 => 40,  88 => 33,  80 => 15,  78 => 25,  46 => 12,  44 => 8,  40 => 16,  36 => 15,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 76,  215 => 204,  211 => 203,  208 => 70,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 62,  180 => 59,  171 => 54,  166 => 51,  163 => 57,  160 => 49,  157 => 48,  149 => 48,  146 => 41,  140 => 52,  137 => 44,  129 => 44,  124 => 20,  121 => 42,  118 => 41,  115 => 40,  111 => 32,  107 => 32,  104 => 61,  97 => 34,  93 => 32,  90 => 35,  81 => 26,  70 => 23,  66 => 15,  62 => 11,  59 => 15,  56 => 12,  52 => 11,  49 => 13,  45 => 18,  41 => 5,  37 => 5,  33 => 3,  30 => 1,);
    }
}
