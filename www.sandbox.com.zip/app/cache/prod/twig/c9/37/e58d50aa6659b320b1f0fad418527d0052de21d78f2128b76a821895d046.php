<?php

/* AcmeHomeBundle:Default:services.html.twig */
class __TwigTemplate_c937e58d50aa6659b320b1f0fad418527d0052de21d78f2128b76a821895d046 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::common.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::common.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"body3\">
\t\t<div class=\"main zerogrid\">
<!-- content -->
\t\t\t<article id=\"content\" style=\"padding-top:0px;\">
\t\t\t\t<div class=\"wrapper\">
\t\t\t\t\t<h2 class=\"under\">Overview of Our Main Business Courses</h2>
\t\t\t\t\t<div class=\"wrapper\">
                                                ";
        // line 10
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "services"));
        foreach ($context['_seq'] as $context["_key"] => $context["ser"]) {
            // line 11
            echo "                                                    <section class=\"col-1-3\">
                                                    <div class=\"wrap-col\">
                                                            <div class=\"wrapper pad_bot1\">    
                                                                <figure class=\"left marg_right1\"><img src=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/services/", 1 => $this->getAttribute($this->getContext($context, "ser"), "id"), 2 => "/", 3 => $this->getAttribute($this->getContext($context, "ser"), "image")))), "html", null, true);
            echo "\" alt=\"\"></figure>
                                                                    <h6>";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "ser"), "title"), "html", null, true);
            echo "</h6>
                                                                    <p>";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "ser"), "description"), "html", null, true);
            echo "</p>
                                                            </div>
                                                    </div>
                                                    </section>
                                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ser'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "  
\t\t\t\t\t</div>
\t\t\t\t</div>

\t\t\t</article>
\t\t</div>
        </div>                                        
\t";
        // line 27
        echo twig_include($this->env, $context, "followUs.html.twig");
        echo "
        ";
        // line 28
        echo twig_include($this->env, $context, "footer.html.twig");
        echo "
<script type=\"text/javascript\"> Cufon.now(); </script>
<script>
\t\$(document).ready(function() {
\t\ttabs.init();
\t})
</script>
";
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle:Default:services.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 28,  77 => 27,  68 => 20,  57 => 16,  53 => 15,  49 => 14,  44 => 11,  40 => 10,  31 => 3,  28 => 2,);
    }
}
