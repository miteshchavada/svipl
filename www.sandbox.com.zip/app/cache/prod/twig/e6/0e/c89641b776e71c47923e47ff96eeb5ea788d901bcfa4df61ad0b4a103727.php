<?php

/* AcmeInfoBundle:Default:contactus.html.twig */
class __TwigTemplate_e60ec89641b776e71c47923e47ff96eeb5ea788d901bcfa4df61ad0b4a103727 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        echo $this->env->getExtension('stfalcon_tinymce')->tinymceInit();
        echo "
    ";
        // line 3
        $this->displayBlock('content', $context, $blocks);
    }

    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "        <div class=\"row\">
            <div class=\"col-lg-12\">
                <h1 class=\"page-header\">ContactUs Details</h1>
            </div>
        </div>
        <!-- /.row -->
        <div class=\"row\">
            <center>
                <form action=\"";
        // line 12
        echo $this->env->getExtension('routing')->getPath("acme_info_contactus");
        echo "\" method=\"POST\">
                    <div style=\"width:70%\">
                        <input type=\"hidden\" value=\"";
        // line 14
        if (isset($context["contactus"])) { $_contactus_ = $context["contactus"]; } else { $_contactus_ = null; }
        echo twig_escape_filter($this->env, $this->getAttribute($_contactus_, "id"), "html", null, true);
        echo "\" name=\"id\">
                        <textarea rows=\"15\" cols=\"60\" name=\"description\">";
        // line 15
        if (isset($context["contactus"])) { $_contactus_ = $context["contactus"]; } else { $_contactus_ = null; }
        echo twig_escape_filter($this->env, $this->getAttribute($_contactus_, "description"), "html", null, true);
        echo "</textarea>
                        <!--textarea class=\"tinymce\"><p name=\"description\">";
        // line 16
        if (isset($context["contactus"])) { $_contactus_ = $context["contactus"]; } else { $_contactus_ = null; }
        echo twig_escape_filter($this->env, $this->getAttribute($_contactus_, "description"), "html", null, true);
        echo "</p></textarea-->
                    </div>            
                    <div>
                        <input type=\"submit\" name=\"submit\" value=\"save\" class=\"btn btn-primary\">
                        <input type=\"reset\" name=\"Reset\" value=\"Reset\" class=\"btn btn-danger\" onclick=\"javascript:window.location.href = '";
        // line 20
        echo $this->env->getExtension('routing')->getPath("acme_info_contactus");
        echo "'\"/>
                    </div>
                </form>
            </center>\t\t\t
        </div>
        <script type=\"text/javascript\" src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/stfalcontinymce/vendor/tinymce/tinymce.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\">
            tinymce.init({
                selector: \"textarea\",
                theme: \"modern\",
                plugins: [
                    \"advlist autolink lists link image charmap print preview hr anchor pagebreak\",
                    \"searchreplace wordcount visualblocks visualchars code fullscreen\",
                    \"insertdatetime media nonbreaking save table contextmenu directionality\",
                    \"emoticons template paste textcolor colorpicker textpattern\"
                ],
                toolbar1: \"insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image\",
                toolbar2: \"print preview media | forecolor backcolor emoticons\",
                image_advtab: true,
                templates: [
                    {title: 'Test template 1', content: 'Test 1'},
                    {title: 'Test template 2', content: 'Test 2'}
                ]
            });
        </script>

    ";
    }

    public function getTemplateName()
    {
        return "AcmeInfoBundle:Default:contactus.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 40,  103 => 36,  132 => 42,  94 => 35,  64 => 16,  182 => 43,  217 => 22,  213 => 21,  209 => 20,  205 => 19,  175 => 11,  73 => 52,  74 => 20,  311 => 116,  270 => 26,  266 => 25,  262 => 24,  258 => 23,  254 => 22,  250 => 21,  246 => 20,  242 => 19,  238 => 18,  233 => 17,  230 => 16,  220 => 13,  216 => 12,  212 => 11,  203 => 9,  172 => 38,  144 => 94,  141 => 45,  82 => 25,  176 => 49,  153 => 35,  148 => 34,  125 => 68,  68 => 32,  145 => 48,  86 => 33,  83 => 55,  206 => 201,  200 => 8,  188 => 117,  179 => 12,  177 => 184,  174 => 183,  159 => 86,  151 => 36,  135 => 80,  99 => 29,  165 => 101,  139 => 81,  126 => 43,  95 => 26,  91 => 31,  87 => 22,  23 => 2,  128 => 32,  116 => 36,  79 => 21,  61 => 15,  20 => 1,  42 => 4,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 29,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 18,  143 => 46,  138 => 44,  134 => 41,  131 => 70,  122 => 38,  117 => 36,  108 => 34,  102 => 28,  92 => 24,  84 => 21,  72 => 32,  48 => 12,  35 => 3,  29 => 2,  69 => 17,  54 => 12,  51 => 12,  31 => 3,  312 => 96,  308 => 94,  293 => 40,  285 => 90,  281 => 88,  277 => 86,  274 => 27,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 81,  204 => 69,  198 => 65,  194 => 6,  150 => 98,  147 => 83,  127 => 40,  112 => 33,  96 => 33,  76 => 20,  71 => 16,  39 => 4,  110 => 20,  89 => 34,  65 => 23,  63 => 12,  58 => 14,  34 => 8,  55 => 12,  26 => 11,  24 => 6,  43 => 10,  114 => 39,  109 => 38,  106 => 17,  101 => 28,  85 => 23,  77 => 53,  67 => 50,  28 => 2,  227 => 92,  224 => 14,  221 => 90,  207 => 70,  197 => 17,  195 => 65,  192 => 16,  189 => 15,  186 => 116,  181 => 67,  178 => 42,  173 => 58,  162 => 58,  158 => 56,  155 => 99,  152 => 40,  142 => 32,  136 => 90,  133 => 35,  130 => 88,  120 => 85,  105 => 62,  100 => 25,  75 => 19,  60 => 16,  53 => 10,  57 => 65,  50 => 13,  47 => 8,  38 => 4,  25 => 3,  19 => 1,  98 => 35,  88 => 75,  80 => 15,  78 => 19,  46 => 12,  44 => 8,  40 => 10,  36 => 4,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 24,  215 => 204,  211 => 203,  208 => 10,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 13,  180 => 50,  171 => 10,  166 => 9,  163 => 8,  160 => 49,  157 => 6,  149 => 81,  146 => 41,  140 => 52,  137 => 71,  129 => 28,  124 => 39,  121 => 19,  118 => 35,  115 => 34,  111 => 32,  107 => 32,  104 => 37,  97 => 34,  93 => 27,  90 => 33,  81 => 20,  70 => 18,  66 => 16,  62 => 11,  59 => 16,  56 => 14,  52 => 12,  49 => 13,  45 => 11,  41 => 4,  37 => 5,  33 => 3,  30 => 1,);
    }
}
