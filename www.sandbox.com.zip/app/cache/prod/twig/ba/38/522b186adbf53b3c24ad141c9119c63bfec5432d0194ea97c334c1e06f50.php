<?php

/* footer.html.twig */
class __TwigTemplate_ba38522b186adbf53b3c24ad141c9119c63bfec5432d0194ea97c334c1e06f50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"main zerogrid\">
    <footer>
        <a href=\"http://www.zerotheme.com/432/free-responsive-html5-css3-website-templates.html\" target=\"_blank\">Html5 Templates</a> by <a href=\"http://www.templatemonster.com/\" target=\"_blank\">Templatesmonster.com</a><br>
        <a href=\"http://www.zerotheme.com/432/free-responsive-html5-css3-website-templates.html\" target=\"_blank\">Responsive Themes</a> by <a href=\"http://www.zerotheme.com/\" target=\"_blank\">Zerotheme.com</a><br>
    </footer>
</div>";
    }

    public function getTemplateName()
    {
        return "footer.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  63 => 34,  51 => 31,  19 => 1,  303 => 116,  285 => 40,  271 => 29,  266 => 27,  262 => 26,  258 => 25,  254 => 24,  250 => 23,  246 => 22,  242 => 21,  238 => 20,  234 => 19,  230 => 18,  225 => 17,  222 => 16,  216 => 14,  212 => 13,  208 => 12,  204 => 11,  200 => 10,  195 => 9,  192 => 8,  186 => 6,  180 => 117,  178 => 116,  171 => 111,  164 => 106,  157 => 101,  144 => 98,  138 => 94,  136 => 93,  131 => 90,  125 => 88,  119 => 86,  116 => 85,  110 => 83,  104 => 81,  95 => 78,  89 => 76,  86 => 75,  80 => 73,  74 => 71,  57 => 65,  49 => 62,  39 => 54,  36 => 16,  34 => 8,  29 => 6,  23 => 2,  165 => 50,  161 => 49,  148 => 99,  139 => 35,  135 => 34,  130 => 32,  126 => 30,  122 => 29,  114 => 23,  105 => 21,  101 => 80,  97 => 18,  77 => 14,  71 => 70,  65 => 68,  59 => 33,  55 => 32,  38 => 8,  31 => 3,  28 => 2,);
    }
}
