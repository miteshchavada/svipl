<?php

/* AcmeHomeBundle:Default:index.html.twig */
class __TwigTemplate_12c57c7feb5474c7ad5e4e57462023f0831049798e366b3d51f1b9349b83aeca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::front.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"body3\">
        <div class=\"main zerogrid\">
            <!-- content -->
            <article id=\"content\">
                <div class=\"wrapper row\">
                    ";
        // line 8
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "info"));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["inf"]) {
            // line 9
            echo "                        <section class=\"col-1-4\">
                            <div class=\"wrap-col\">
                                <h3><span class=\"dropcap\">";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "loop"), "index"), "html", null, true);
            echo "</span>";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "inf"), "title"), "html", null, true);
            echo "</h3>
                                <p class=\"pad_bot1\" id=\"desc_";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "inf"), "id"), "html", null, true);
            echo "\" style=\"display:block;\">";
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($this->getContext($context, "inf"), "description"), 0, 50), "html", null, true);
            echo "</p>
                                <p class=\"pad_bot1\" id=\"pname_";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "inf"), "id"), "html", null, true);
            echo "\" style=\"display:none;\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "inf"), "description"), "html", null, true);
            echo "</p>
                                <a href=\"Javascript:toggle('pname_";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "inf"), "id"), "html", null, true);
            echo "','desc_";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "inf"), "id"), "html", null, true);
            echo "');\" class=\"link1\">Read More</a>
                            </div>
                        </section>
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['inf'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "                </div>
                <div class=\"wrapper row\">
                    ";
        // line 20
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "front"));
        foreach ($context['_seq'] as $context["_key"] => $context["fnt"]) {
            // line 21
            echo "                        ";
            echo $this->getAttribute($this->getContext($context, "fnt"), "description");
            echo "
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fnt'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "                    <section class=\"col-1-4\">
                        <div class=\"wrap-col\">
                            <h2>Testimonials</h2>
                            <div class=\"testimonials\">
                                <div id=\"testimonials\">
                                    <ul>
                                        ";
        // line 29
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "testimonials"));
        foreach ($context['_seq'] as $context["_key"] => $context["testi"]) {
            // line 30
            echo "                                            <li>
                                                <div>
                                                    ";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "testi"), "description"), "html", null, true);
            echo "
                                                </div>
                                                <span><strong class=\"color1\">";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "testi"), "name"), "html", null, true);
            echo ",</strong> <br>
                                                    ";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "testi"), "post"), "html", null, true);
            echo "</span>
                                            </li>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['testi'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "                                    </ul>
                                </div>
                                <a href=\"#\" class=\"up\"></a>
                                <a href=\"#\" class=\"down\"></a>
                            </div>
                        </div>
                    </section>
                </div>
            </article>
        </div>
    </div>
    ";
        // line 49
        echo twig_include($this->env, $context, "followUs.html.twig");
        echo "
    ";
        // line 50
        echo twig_include($this->env, $context, "footer.html.twig");
        echo "                                                             
    <script type=\"text/javascript\"> Cufon.now();</script>
    <script type=\"text/javascript\">
        function toggle(obj, obj1) {

            var toggle = document.getElementById(obj);
            var desc = document.getElementById(obj1);

            if (toggle.style.display != \"none\") {
                toggle.style.display = \"none\";
                desc.style.display = \"block\";
            }
            else {
                toggle.style.display = \"block\";
                desc.style.display = \"none\";
            }
        }
    </script>
";
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 50,  161 => 49,  148 => 38,  139 => 35,  135 => 34,  130 => 32,  126 => 30,  122 => 29,  114 => 23,  105 => 21,  101 => 20,  97 => 18,  77 => 14,  71 => 13,  65 => 12,  59 => 11,  55 => 9,  38 => 8,  31 => 3,  28 => 2,);
    }
}
