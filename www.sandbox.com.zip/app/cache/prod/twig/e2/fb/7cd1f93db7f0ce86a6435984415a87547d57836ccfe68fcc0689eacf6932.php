<?php

/* AcmeHomeBundle:Default:contact.html.twig */
class __TwigTemplate_e2fb7cd1f93db7f0ce86a6435984415a87547d57836ccfe68fcc0689eacf6932 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::common.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::common.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"body3\">
        <div class=\"main zerogrid\">
            <!-- content -->
            <article id=\"content\">
                <div class=\"wrapper row\">
                    <section class=\"col-3-4\">
                        <div class=\"wrap-col\">
                            <h2 class=\"under\">Contact form</h2>
                            ";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "session"), "flashbag"), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 12
            echo "                                <div class=\"flash notice\">
                                    ";
            // line 13
            echo twig_escape_filter($this->env, $this->getContext($context, "flashMessage"), "html", null, true);
            echo "
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "
                            <form id=\"ContactForm\" method=\"post\" action=\"sendEmail\" >
                                <div>
                                    <div  class=\"wrapper\">
                                        <span>Your Name:</span>
                                        <input type=\"text\" class=\"input\" name=\"name\">
                                    </div>
                                    <div  class=\"wrapper\">
                                        <span>Your City:</span>
                                        <input type=\"text\" class=\"input\" name=\"city\">
                                    </div>
                                    <div  class=\"wrapper\">
                                        <span>Your E-mail:</span>
                                        <input type=\"text\" class=\"input\" name=\"email\">
                                    </div>
                                    <div  class=\"textarea_box\">
                                        <span>Your Message:</span>
                                        <textarea name=\"description\" cols=\"1\" rows=\"1\"></textarea>
                                    </div>
                                    <a href=\"#\" onClick=\"document.getElementById('ContactForm').submit()\">Send</a>
                                    <a href=\"#\" onClick=\"document.getElementById('ContactForm').reset()\">Clear</a>
                                </div>
                            </form>
                        </div>
                    </section>
                    ";
        // line 41
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "contactus"));
        foreach ($context['_seq'] as $context["_key"] => $context["contact"]) {
            // line 42
            echo "                        ";
            echo $this->getAttribute($this->getContext($context, "contact"), "description");
            echo "
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['contact'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "                </div>

            </article>
        </div>
    </div>
    ";
        // line 49
        echo twig_include($this->env, $context, "followUs.html.twig");
        echo "
    ";
        // line 50
        echo twig_include($this->env, $context, "footer.html.twig");
        echo "
    <script type=\"text/javascript\"> Cufon.now();</script>
    <script>
        \$(document).ready(function () {
            tabs.init();
        })
    </script>
";
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle:Default:contact.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  108 => 50,  104 => 49,  97 => 44,  88 => 42,  84 => 41,  57 => 16,  48 => 13,  45 => 12,  41 => 11,  31 => 3,  28 => 2,);
    }
}
