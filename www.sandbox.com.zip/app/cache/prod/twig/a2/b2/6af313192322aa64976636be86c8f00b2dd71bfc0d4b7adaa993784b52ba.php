<?php

/* TwigBundle:Exception:logs.html.twig */
class __TwigTemplate_a2b26af313192322aa64976636be86c8f00b2dd71bfc0d4b7adaa993784b52ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<ol class=\"traces logs\">
    ";
        // line 2
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "logs"));
        foreach ($context['_seq'] as $context["_key"] => $context["log"]) {
            // line 3
            echo "        <li";
            if (($this->getAttribute($this->getContext($context, "log"), "priority") >= 400)) {
                echo " class=\"error\"";
            } elseif (($this->getAttribute($this->getContext($context, "log"), "priority") >= 300)) {
                echo " class=\"warning\"";
            }
            echo ">
            ";
            // line 4
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "log"), "priorityName"), "html", null, true);
            echo " - ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "log"), "message"), "html", null, true);
            echo "
        </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['log'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 7
        echo "</ol>
";
    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:logs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 4,  26 => 3,  87 => 20,  55 => 13,  31 => 5,  25 => 4,  21 => 2,  94 => 22,  89 => 20,  85 => 19,  79 => 18,  75 => 17,  72 => 16,  68 => 14,  64 => 12,  56 => 9,  50 => 8,  41 => 9,  24 => 3,  201 => 92,  196 => 90,  183 => 82,  171 => 73,  168 => 72,  166 => 71,  163 => 70,  156 => 66,  151 => 63,  136 => 56,  133 => 55,  123 => 47,  121 => 46,  117 => 44,  115 => 43,  112 => 42,  105 => 40,  101 => 24,  91 => 31,  86 => 28,  69 => 25,  66 => 15,  62 => 23,  49 => 19,  19 => 1,  93 => 9,  88 => 6,  80 => 19,  78 => 40,  44 => 10,  27 => 4,  22 => 2,  54 => 21,  43 => 8,  33 => 5,  30 => 3,  231 => 184,  214 => 204,  210 => 203,  205 => 201,  199 => 91,  193 => 195,  187 => 84,  178 => 185,  176 => 184,  173 => 74,  162 => 168,  158 => 67,  154 => 85,  150 => 84,  146 => 83,  142 => 59,  138 => 57,  134 => 80,  130 => 79,  114 => 66,  108 => 63,  103 => 61,  98 => 40,  92 => 21,  57 => 14,  45 => 18,  40 => 8,  36 => 7,  20 => 1,  51 => 12,  46 => 7,  39 => 6,  32 => 12,  29 => 2,);
    }
}
