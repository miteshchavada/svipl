<?php

/* ::base.html.twig */
class __TwigTemplate_9c510ab0388860192a79c9b0c4c2fc0879b3e27ef39f42d0193cadcbeff06a28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>

    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>SB Admin 2 - Bootstrap Admin Theme</title>

    <!-- Bootstrap Core CSS -->
    <link href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/css/plugins/dataTables.bootstrap.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <!-- MetisMenu CSS -->
    <link href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/css/plugins/metisMenu/metisMenu.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    <!-- Custom CSS -->
    <link href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/css/sb-admin-2.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    <!-- Custom Fonts -->
    <link href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/css/font-awesome-4.1.0/css/font-awesome.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
        <script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>
    <![endif]-->

</head>

<body>

    <div id=\"wrapper\">

        <!-- Navigation -->
        <nav class=\"navbar navbar-default navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"index.html\">SVIPL Admin</a>
            </div>
            <!-- /.navbar-header -->

            <ul class=\"nav navbar-top-links navbar-right\">
                <!-- /.dropdown -->
                <li class=\"dropdown\">
                    <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                        <i class=\"fa fa-user fa-fw\"></i>";
        // line 56
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute($_app_, "user"), "username")), "FOSUserBundle"), "html", null, true);
        echo " <i class=\"fa fa-caret-down\"></i>
                    </a>
                    <ul class=\"dropdown-menu dropdown-user\">
                        <li><a href=";
        // line 59
        echo $this->env->getExtension('routing')->getPath("fos_user_profile_show");
        echo "><i class=\"fa fa-user fa-fw\"></i> User Profile</a>
                        </li>
                        <li><a href=\"";
        // line 61
        echo $this->env->getExtension('routing')->getPath("fos_user_registration_register");
        echo "\"><i class=\"fa fa-user fa-fw\"></i> New Registration</a>
                        </li>
                        <li><a href=\"";
        // line 63
        echo $this->env->getExtension('routing')->getPath("fos_user_change_password");
        echo "\"><i class=\"fa fa-user fa-fw\"></i> Change Password</a>
                        </li>
                        <li class=\"divider\"></li>
                        <li><a href=\"";
        // line 66
        echo $this->env->getExtension('routing')->getPath("fos_user_security_logout");
        echo "\">
                            <i class=\"fa fa-sign-out fa-fw\"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class=\"navbar-default sidebar\" role=\"navigation\">
                <div class=\"sidebar-nav navbar-collapse\">
                    <ul class=\"nav\" id=\"side-menu\">
                        <li><a href=\"";
        // line 79
        echo $this->env->getExtension('routing')->getPath("acme_store");
        echo "\"><i class=\"fa fa-dashboard fa-fw\"></i>Store</a></li>
                        <li><a href=\"";
        // line 80
        echo $this->env->getExtension('routing')->getPath("acme_image");
        echo "\"><i class=\"fa fa-table fa-fw\"></i>Slider Image</a></li>
                        <li><a href=\"";
        // line 81
        echo $this->env->getExtension('routing')->getPath("acme_info");
        echo "\"><i class=\"fa fa-sitemap fa-fw\"></i>Info</a></li>
                        <li><a href=\"";
        // line 82
        echo $this->env->getExtension('routing')->getPath("acme_info_welcome");
        echo "\"><i class=\"fa fa-edit fa-fw\"></i>Front</a></li>
                        <li><a href=\"";
        // line 83
        echo $this->env->getExtension('routing')->getPath("acme_info_testimonials");
        echo "\"><i class=\"fa fa-wrench fa-fw\"></i>Testimonials</a></li> \t
                        <li><a href=\"";
        // line 84
        echo $this->env->getExtension('routing')->getPath("acme_info_newslist");
        echo "\"><i class=\"fa fa-files-o fa-fw\"></i>News</a></li>
                        <li><a href=\"";
        // line 85
        echo $this->env->getExtension('routing')->getPath("acme_info_serviceslist");
        echo "\"><i class=\"fa fa-envelope fa-fw\"></i>Services</a></li>
                        <li><a href=\"";
        // line 86
        echo $this->env->getExtension('routing')->getPath("acme_info_contactus");
        echo "\"><i class=\"fa fa-bell fa-fw\"></i>ContactUs</a></li>
                        ";
        // line 168
        echo "                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <!-- Page Content -->
        <div id=\"page-wrapper\">
            ";
        // line 183
        echo "            <!-- /.row -->
            ";
        // line 184
        $this->displayBlock('body', $context, $blocks);
        // line 185
        echo "        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery Version 1.11.0 -->
    <script src=\"";
        // line 192
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/js/jquery-1.11.0.js"), "html", null, true);
        echo "\"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src=\"";
        // line 195
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src=\"";
        // line 198
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/js/plugins/metisMenu/metisMenu.min.js"), "html", null, true);
        echo "\"></script>

    <!-- Custom Theme JavaScript -->
    <script src=\"";
        // line 201
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/js/sb-admin-2.js"), "html", null, true);
        echo "\"></script>
    <!-- DataTables JavaScript -->
    <script src=\"";
        // line 203
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/js/plugins/dataTables/jquery.dataTables.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 204
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmeuser/js/plugins/dataTables/dataTables.bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script>
        \$(document).ready(function () {
            \$('#dataTables-example').dataTable();
        });
        \$(document).ready(function () {
            \$('#dataTables-example1').dataTable();
        });
    </script>
</body>

</html>
";
    }

    // line 184
    public function block_body($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  206 => 201,  200 => 198,  188 => 192,  179 => 185,  177 => 184,  174 => 183,  159 => 86,  151 => 84,  135 => 80,  99 => 59,  165 => 51,  139 => 81,  126 => 43,  95 => 36,  91 => 31,  87 => 34,  23 => 3,  128 => 46,  116 => 41,  79 => 17,  61 => 22,  20 => 1,  42 => 10,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 78,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 66,  143 => 82,  138 => 44,  134 => 49,  131 => 79,  122 => 43,  117 => 36,  108 => 31,  102 => 28,  92 => 56,  84 => 31,  72 => 15,  48 => 13,  35 => 5,  29 => 2,  69 => 33,  54 => 14,  51 => 21,  31 => 4,  312 => 96,  308 => 94,  293 => 92,  285 => 90,  281 => 88,  277 => 86,  274 => 85,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 73,  204 => 69,  198 => 65,  194 => 195,  150 => 54,  147 => 83,  127 => 41,  112 => 19,  96 => 33,  76 => 16,  71 => 26,  39 => 12,  110 => 39,  89 => 16,  65 => 23,  63 => 12,  58 => 11,  34 => 4,  55 => 15,  26 => 11,  24 => 6,  43 => 7,  114 => 22,  109 => 63,  106 => 17,  101 => 19,  85 => 28,  77 => 12,  67 => 19,  28 => 3,  227 => 92,  224 => 91,  221 => 90,  207 => 70,  197 => 74,  195 => 65,  192 => 72,  189 => 61,  186 => 60,  181 => 67,  178 => 61,  173 => 58,  162 => 58,  158 => 56,  155 => 85,  152 => 40,  142 => 52,  136 => 44,  133 => 43,  130 => 42,  120 => 40,  105 => 38,  100 => 37,  75 => 23,  60 => 12,  53 => 10,  57 => 24,  50 => 7,  47 => 8,  38 => 4,  25 => 3,  19 => 1,  98 => 40,  88 => 33,  80 => 15,  78 => 25,  46 => 12,  44 => 8,  40 => 16,  36 => 15,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 76,  215 => 204,  211 => 203,  208 => 70,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 62,  180 => 59,  171 => 54,  166 => 51,  163 => 168,  160 => 49,  157 => 48,  149 => 48,  146 => 41,  140 => 52,  137 => 37,  129 => 44,  124 => 20,  121 => 42,  118 => 41,  115 => 66,  111 => 32,  107 => 28,  104 => 61,  97 => 34,  93 => 32,  90 => 35,  81 => 26,  70 => 23,  66 => 13,  62 => 11,  59 => 15,  56 => 12,  52 => 11,  49 => 9,  45 => 18,  41 => 5,  37 => 5,  33 => 3,  30 => 1,);
    }
}
