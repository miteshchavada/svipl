<?php

/* AcmeHomeBundle::layout.html.twig */
class __TwigTemplate_5feb6f9d89951086d86a9d3ba68355ac629a43de06cd6711275352dddf3b54a0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("TwigBundle::layout.html.twig");

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content_header' => array($this, 'block_content_header'),
            'content_header_more' => array($this, 'block_content_header_more'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        // line 4
        echo "    <link rel=\"icon\" sizes=\"16x16\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/css/demo.css"), "html", null, true);
        echo "\" />
";
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        echo "Demo Bundle";
    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        echo "\t
    ";
        // line 11
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute($_app_, "session"), "flashbag"), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 12
            echo "        <div class=\"flash-message\">
            <em>Notice</em>: ";
            // line 13
            if (isset($context["flashMessage"])) { $_flashMessage_ = $context["flashMessage"]; } else { $_flashMessage_ = null; }
            echo twig_escape_filter($this->env, $_flashMessage_, "html", null, true);
            echo "
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "
    ";
        // line 17
        $this->displayBlock('content_header', $context, $blocks);
        // line 26
        echo "
    <div class=\"block\">
        ";
        // line 28
        $this->displayBlock('content', $context, $blocks);
        // line 29
        echo "    </div>

    ";
        // line 31
        if (array_key_exists("code", $context)) {
            // line 32
            echo "        <h2>Code behind this page</h2>
        <div class=\"block\">
            <div class=\"symfony-content\">";
            // line 34
            if (isset($context["code"])) { $_code_ = $context["code"]; } else { $_code_ = null; }
            echo $_code_;
            echo "</div>
        </div>
    ";
        }
    }

    // line 17
    public function block_content_header($context, array $blocks = array())
    {
        // line 18
        echo "        <ul id=\"menu\">
            ";
        // line 19
        $this->displayBlock('content_header_more', $context, $blocks);
        // line 22
        echo "        </ul>

        <div style=\"clear: both\"></div>
    ";
    }

    // line 19
    public function block_content_header_more($context, array $blocks = array())
    {
        // line 20
        echo "                
            ";
    }

    // line 28
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  182 => 43,  217 => 22,  213 => 21,  209 => 20,  205 => 19,  175 => 11,  73 => 52,  74 => 14,  311 => 116,  270 => 26,  266 => 25,  262 => 24,  258 => 23,  254 => 22,  250 => 21,  246 => 20,  242 => 19,  238 => 18,  233 => 17,  230 => 16,  220 => 13,  216 => 12,  212 => 11,  203 => 9,  172 => 38,  144 => 94,  141 => 93,  82 => 15,  176 => 49,  153 => 35,  148 => 34,  125 => 68,  68 => 12,  145 => 48,  86 => 41,  83 => 55,  206 => 201,  200 => 8,  188 => 117,  179 => 12,  177 => 184,  174 => 183,  159 => 86,  151 => 36,  135 => 80,  99 => 60,  165 => 101,  139 => 81,  126 => 43,  95 => 36,  91 => 31,  87 => 29,  23 => 2,  128 => 32,  116 => 36,  79 => 17,  61 => 48,  20 => 1,  42 => 10,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 29,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 18,  143 => 46,  138 => 30,  134 => 41,  131 => 70,  122 => 38,  117 => 36,  108 => 49,  102 => 28,  92 => 24,  84 => 14,  72 => 20,  48 => 12,  35 => 5,  29 => 6,  69 => 13,  54 => 12,  51 => 21,  31 => 3,  312 => 96,  308 => 94,  293 => 40,  285 => 90,  281 => 88,  277 => 86,  274 => 27,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 81,  204 => 69,  198 => 65,  194 => 6,  150 => 98,  147 => 83,  127 => 41,  112 => 19,  96 => 33,  76 => 16,  71 => 16,  39 => 35,  110 => 20,  89 => 57,  65 => 23,  63 => 12,  58 => 11,  34 => 8,  55 => 15,  26 => 11,  24 => 6,  43 => 10,  114 => 22,  109 => 18,  106 => 17,  101 => 44,  85 => 28,  77 => 53,  67 => 50,  28 => 2,  227 => 92,  224 => 14,  221 => 90,  207 => 70,  197 => 17,  195 => 65,  192 => 16,  189 => 15,  186 => 116,  181 => 67,  178 => 42,  173 => 58,  162 => 58,  158 => 56,  155 => 99,  152 => 40,  142 => 32,  136 => 90,  133 => 35,  130 => 88,  120 => 85,  105 => 62,  100 => 25,  75 => 19,  60 => 16,  53 => 10,  57 => 65,  50 => 14,  47 => 8,  38 => 8,  25 => 3,  19 => 1,  98 => 17,  88 => 75,  80 => 15,  78 => 20,  46 => 12,  44 => 8,  40 => 10,  36 => 4,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 24,  215 => 204,  211 => 203,  208 => 10,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 13,  180 => 50,  171 => 10,  166 => 9,  163 => 8,  160 => 49,  157 => 6,  149 => 81,  146 => 41,  140 => 52,  137 => 71,  129 => 28,  124 => 20,  121 => 19,  118 => 29,  115 => 65,  111 => 32,  107 => 32,  104 => 80,  97 => 34,  93 => 32,  90 => 16,  81 => 26,  70 => 18,  66 => 13,  62 => 11,  59 => 16,  56 => 13,  52 => 12,  49 => 13,  45 => 11,  41 => 5,  37 => 5,  33 => 3,  30 => 1,);
    }
}
