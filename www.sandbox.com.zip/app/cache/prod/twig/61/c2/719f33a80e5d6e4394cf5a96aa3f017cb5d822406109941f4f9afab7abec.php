<?php

/* AcmeHomeBundle:Default:news.html.twig */
class __TwigTemplate_61c2719f33a80e5d6e4394cf5a96aa3f017cb5d822406109941f4f9afab7abec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::common.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::common.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"body3\">
        <div class=\"main zerogrid\">
            <!-- content -->
            <article id=\"content\">
                <div class=\"wrapper tabs\">
                    ";
        // line 8
        $context["i"] = 0;
        // line 9
        echo "                    ";
        $context["divNo"] = 1;
        // line 10
        echo "                    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "news"));
        foreach ($context['_seq'] as $context["_key"] => $context["new"]) {
            // line 11
            echo "
                        ";
            // line 12
            if (((($this->getContext($context, "i") % 3) == 0) && ($this->getContext($context, "divNo") != 1))) {
                // line 13
                echo "                        </div>
                    ";
            }
            // line 15
            echo "
                    ";
            // line 16
            if ((($this->getContext($context, "i") % 3) == 0)) {
                // line 17
                echo "                        <div class=\"tab-content\" id=\"tab";
                echo twig_escape_filter($this->env, $this->getContext($context, "divNo"), "html", null, true);
                echo "\">
                            ";
                // line 18
                $context["divNo"] = ($this->getContext($context, "divNo") + 1);
                // line 19
                echo "                        ";
            }
            // line 20
            echo "
                        <h5><span class=\"dropcap\"><strong>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "</strong><span>06</span></span>Lorem ipsum dolor sit amet consectetur adipisicing elit</h5>
                        <div class=\"wrapper pad_bot2\">
                            <figure class=\"left marg_right1\"><img src=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/news/", 1 => $this->getAttribute($this->getContext($context, "new"), "id"), 2 => "/", 3 => $this->getAttribute($this->getContext($context, "new"), "image")))), "html", null, true);
            echo "\" alt=\"\"></figure>
                            <p class=\"pad_bot1\" id=\"desc_";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "\" style=\"display:block;\">";
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($this->getContext($context, "new"), "description"), 0, 200), "html", null, true);
            echo "</p>
                            <p class=\"pad_bot1\" id=\"pname_";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "\" style=\"display:none;\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "description"), "html", null, true);
            echo "</p>
                            <a href=\"Javascript:toggle('pname_";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "','desc_";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "');\" class=\"link1\">Read More</a>
                        </div>

                        ";
            // line 29
            $context["i"] = ($this->getContext($context, "i") + 1);
            // line 30
            echo "
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['new'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                </div>

                <ul class=\"nav\">
                    ";
        // line 35
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(1, twig_round(($this->getContext($context, "count") / 3), 0, "ceil")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["j"]) {
            // line 36
            echo "                        <li class=\"selected\"><a href=\"#tab";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "loop"), "index"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "loop"), "index"), "html", null, true);
            echo "</a></li>
                        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['j'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "                </ul>
            </article>    
        </div>
    </div>            
    ";
        // line 42
        echo twig_include($this->env, $context, "followUs.html.twig");
        echo "
    ";
        // line 43
        echo twig_include($this->env, $context, "footer.html.twig");
        echo "                                      
    <script type=\"text/javascript\"> Cufon.now();</script>
    <script>
        \$(document).ready(function () {
            tabs.init();
        })
    </script>
    <script type=\"text/javascript\">
        function toggle(obj, obj1) {

            var toggle = document.getElementById(obj);
            var desc = document.getElementById(obj1);

            if (toggle.style.display != \"none\") {
                toggle.style.display = \"none\";
                desc.style.display = \"block\";
            }
            else {
                toggle.style.display = \"block\";
                desc.style.display = \"none\";
            }
        }
    </script>
";
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle:Default:news.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 43,  160 => 42,  154 => 38,  135 => 36,  118 => 35,  113 => 32,  106 => 30,  104 => 29,  96 => 26,  90 => 25,  84 => 24,  80 => 23,  75 => 21,  72 => 20,  69 => 19,  67 => 18,  62 => 17,  60 => 16,  57 => 15,  53 => 13,  51 => 12,  48 => 11,  43 => 10,  40 => 9,  38 => 8,  31 => 3,  28 => 2,);
    }
}
