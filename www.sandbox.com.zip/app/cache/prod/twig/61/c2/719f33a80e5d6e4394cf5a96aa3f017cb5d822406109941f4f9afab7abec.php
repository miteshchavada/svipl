<?php

/* AcmeHomeBundle:Default:news.html.twig */
class __TwigTemplate_61c2719f33a80e5d6e4394cf5a96aa3f017cb5d822406109941f4f9afab7abec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::common.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::common.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"body3\">
        <div class=\"main zerogrid\">
            <!-- content -->
            <article id=\"content\">
                <div class=\"wrapper tabs\">
                    ";
        // line 8
        $context["i"] = 0;
        // line 9
        echo "                    ";
        $context["divNo"] = 1;
        // line 10
        echo "                    ";
        if (isset($context["news"])) { $_news_ = $context["news"]; } else { $_news_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_news_);
        foreach ($context['_seq'] as $context["_key"] => $context["new"]) {
            // line 11
            echo "
                        ";
            // line 12
            if (isset($context["i"])) { $_i_ = $context["i"]; } else { $_i_ = null; }
            if (isset($context["divNo"])) { $_divNo_ = $context["divNo"]; } else { $_divNo_ = null; }
            if (((($_i_ % 3) == 0) && ($_divNo_ != 1))) {
                // line 13
                echo "                        </div>
                    ";
            }
            // line 15
            echo "
                    ";
            // line 16
            if (isset($context["i"])) { $_i_ = $context["i"]; } else { $_i_ = null; }
            if ((($_i_ % 3) == 0)) {
                // line 17
                echo "                        <div class=\"tab-content\" id=\"tab";
                if (isset($context["divNo"])) { $_divNo_ = $context["divNo"]; } else { $_divNo_ = null; }
                echo twig_escape_filter($this->env, $_divNo_, "html", null, true);
                echo "\">
                            ";
                // line 18
                if (isset($context["divNo"])) { $_divNo_ = $context["divNo"]; } else { $_divNo_ = null; }
                $context["divNo"] = ($_divNo_ + 1);
                // line 19
                echo "                        ";
            }
            // line 20
            echo "
                        <h5><span class=\"dropcap\"><strong>";
            // line 21
            if (isset($context["new"])) { $_new_ = $context["new"]; } else { $_new_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_, "id"), "html", null, true);
            echo "</strong><span>06</span></span>Lorem ipsum dolor sit amet consectetur adipisicing elit</h5>
                        <div class=\"wrapper pad_bot2\">
                            <figure class=\"left marg_right1\"><img src=\"";
            // line 23
            if (isset($context["new"])) { $_new_ = $context["new"]; } else { $_new_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/news/", 1 => $this->getAttribute($_new_, "id"), 2 => "/", 3 => $this->getAttribute($_new_, "image")))), "html", null, true);
            echo "\" alt=\"\"></figure>
                            <p class=\"pad_bot1\" id=\"desc_";
            // line 24
            if (isset($context["new"])) { $_new_ = $context["new"]; } else { $_new_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_, "id"), "html", null, true);
            echo "\" style=\"display:block;\">";
            if (isset($context["new"])) { $_new_ = $context["new"]; } else { $_new_ = null; }
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($_new_, "description"), 0, 200), "html", null, true);
            echo "</p>
                            <p class=\"pad_bot1\" id=\"pname_";
            // line 25
            if (isset($context["new"])) { $_new_ = $context["new"]; } else { $_new_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_, "id"), "html", null, true);
            echo "\" style=\"display:none;\">";
            if (isset($context["new"])) { $_new_ = $context["new"]; } else { $_new_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_, "description"), "html", null, true);
            echo "</p>
                            <a href=\"Javascript:toggle('pname_";
            // line 26
            if (isset($context["new"])) { $_new_ = $context["new"]; } else { $_new_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_, "id"), "html", null, true);
            echo "','desc_";
            if (isset($context["new"])) { $_new_ = $context["new"]; } else { $_new_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_new_, "id"), "html", null, true);
            echo "');\" class=\"link1\">Read More</a>
                        </div>

                        ";
            // line 29
            if (isset($context["i"])) { $_i_ = $context["i"]; } else { $_i_ = null; }
            $context["i"] = ($_i_ + 1);
            // line 30
            echo "
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['new'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                </div>

                <ul class=\"nav\">
                    ";
        // line 35
        if (isset($context["count"])) { $_count_ = $context["count"]; } else { $_count_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(1, twig_round(($_count_ / 3), 0, "ceil")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["j"]) {
            // line 36
            echo "                        <li class=\"selected\"><a href=\"#tab";
            if (isset($context["loop"])) { $_loop_ = $context["loop"]; } else { $_loop_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_loop_, "index"), "html", null, true);
            echo "\">";
            if (isset($context["loop"])) { $_loop_ = $context["loop"]; } else { $_loop_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_loop_, "index"), "html", null, true);
            echo "</a></li>
                        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['j'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "                </ul>
            </article>    
        </div>
    </div>            
    ";
        // line 42
        echo twig_include($this->env, $context, "followUs.html.twig");
        echo "
    ";
        // line 43
        echo twig_include($this->env, $context, "footer.html.twig");
        echo "                                      
    <script type=\"text/javascript\"> Cufon.now();</script>
    <script>
        \$(document).ready(function () {
            tabs.init();
        })
    </script>
    <script type=\"text/javascript\">
        function toggle(obj, obj1) {

            var toggle = document.getElementById(obj);
            var desc = document.getElementById(obj1);

            if (toggle.style.display != \"none\") {
                toggle.style.display = \"none\";
                desc.style.display = \"block\";
            }
            else {
                toggle.style.display = \"block\";
                desc.style.display = \"none\";
            }
        }
    </script>
";
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle:Default:news.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  182 => 43,  217 => 22,  213 => 21,  209 => 20,  205 => 19,  175 => 11,  73 => 52,  74 => 14,  311 => 116,  270 => 26,  266 => 25,  262 => 24,  258 => 23,  254 => 22,  250 => 21,  246 => 20,  242 => 19,  238 => 18,  233 => 17,  230 => 16,  220 => 13,  216 => 12,  212 => 11,  203 => 9,  172 => 38,  144 => 94,  141 => 93,  82 => 15,  176 => 49,  153 => 35,  148 => 34,  125 => 68,  68 => 12,  145 => 48,  86 => 21,  83 => 55,  206 => 201,  200 => 8,  188 => 117,  179 => 12,  177 => 184,  174 => 183,  159 => 86,  151 => 36,  135 => 80,  99 => 60,  165 => 101,  139 => 81,  126 => 43,  95 => 36,  91 => 31,  87 => 23,  23 => 2,  128 => 32,  116 => 36,  79 => 17,  61 => 48,  20 => 1,  42 => 10,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 29,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 18,  143 => 46,  138 => 30,  134 => 41,  131 => 70,  122 => 38,  117 => 36,  108 => 26,  102 => 28,  92 => 24,  84 => 14,  72 => 18,  48 => 12,  35 => 5,  29 => 6,  69 => 13,  54 => 12,  51 => 21,  31 => 3,  312 => 96,  308 => 94,  293 => 40,  285 => 90,  281 => 88,  277 => 86,  274 => 27,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 81,  204 => 69,  198 => 65,  194 => 6,  150 => 98,  147 => 83,  127 => 41,  112 => 19,  96 => 33,  76 => 71,  71 => 16,  39 => 35,  110 => 20,  89 => 57,  65 => 23,  63 => 16,  58 => 47,  34 => 8,  55 => 12,  26 => 11,  24 => 6,  43 => 10,  114 => 83,  109 => 63,  106 => 18,  101 => 30,  85 => 25,  77 => 53,  67 => 50,  28 => 2,  227 => 92,  224 => 14,  221 => 90,  207 => 70,  197 => 17,  195 => 65,  192 => 16,  189 => 15,  186 => 116,  181 => 67,  178 => 42,  173 => 58,  162 => 58,  158 => 56,  155 => 99,  152 => 40,  142 => 32,  136 => 90,  133 => 35,  130 => 88,  120 => 85,  105 => 62,  100 => 25,  75 => 19,  60 => 15,  53 => 10,  57 => 65,  50 => 44,  47 => 11,  38 => 8,  25 => 3,  19 => 1,  98 => 17,  88 => 75,  80 => 15,  78 => 20,  46 => 12,  44 => 8,  40 => 9,  36 => 15,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 24,  215 => 204,  211 => 203,  208 => 10,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 13,  180 => 50,  171 => 10,  166 => 9,  163 => 8,  160 => 49,  157 => 6,  149 => 81,  146 => 41,  140 => 52,  137 => 71,  129 => 44,  124 => 26,  121 => 30,  118 => 29,  115 => 65,  111 => 32,  107 => 32,  104 => 80,  97 => 34,  93 => 58,  90 => 16,  81 => 21,  70 => 18,  66 => 17,  62 => 11,  59 => 15,  56 => 13,  52 => 12,  49 => 11,  45 => 18,  41 => 5,  37 => 5,  33 => 3,  30 => 1,);
    }
}
