<?php

/* AcmeStoreBundle:Default:edit.html.twig */
class __TwigTemplate_e15daaa8fbf0c20dc674cbc0db9b26acff7facf3174ff8f7329befdd020adeb6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        $this->displayBlock('content', $context, $blocks);
    }

    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <h1 class=\"page-header\">Edit Product</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class=\"row\">
                <center>
                    <form action=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("edit", array("id" => $this->getContext($context, "id"))), "html", null, true);
        echo "\" method=\"post\" id=\"form\" enctype=\"multipart/form-data\" name=\"form\" class=\"form-group\" novalidate=\"novalidate\">
";
        // line 15
        echo "                        ";
        if ((!$this->getAttribute($this->getAttribute($this->getContext($context, "form"), "vars"), "valid"))) {
            // line 16
            echo "                        <div class=\"alert alert-danger\">    
\t\t\t\t";
            // line 17
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "name"), 'errors');
            echo "
\t\t\t\t";
            // line 18
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "price"), 'errors');
            echo "
\t\t\t\t";
            // line 19
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "description"), 'errors');
            echo "
                                ";
            // line 20
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "image"), 'errors');
            echo "
                        </div>
                        ";
        }
        // line 23
        echo "                        <div class=\"form-group col-lg-12\">
                        ";
        // line 24
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "category"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Category: "));
        echo "
                        <div class=\"col-sm-10\">
                            ";
        // line 26
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "category"), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Category Name")));
        echo "  
                        </div>
                    </div>
                        <div class=\"form-group col-lg-12\">
                            ";
        // line 30
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "name"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Name: "));
        echo "
                            <div class=\"col-sm-10\">
                              ";
        // line 32
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "name"), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Product Name", "value" => $this->getAttribute($this->getContext($context, "product"), "name"))));
        echo "  
                            </div>
                        </div>
                        <div class=\"form-group col-lg-12\">
                            ";
        // line 36
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "price"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Price: "));
        echo "
                            <div class=\"col-sm-10\">
                            ";
        // line 38
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "price"), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Price", "value" => $this->getAttribute($this->getContext($context, "product"), "price"))));
        echo "
                            </div>
                        </div>
                        <div class=\"form-group col-lg-12\">
                            ";
        // line 42
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "description"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Description: "));
        echo "
                            <div class=\"col-sm-10\">
                            ";
        // line 44
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "description"), 'widget', array("value" => $this->getAttribute($this->getContext($context, "product"), "description"), "attr" => array("class" => "form-control")));
        echo "
                            </div>
                        </div>
                        <div class=\"form-group col-lg-12\">
                            ";
        // line 48
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "image"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "File: "));
        echo "
                            <div class=\"col-sm-2\">
                                ";
        // line 50
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "image"), 'widget', array("attr" => array("class" => "btn btn-default btn-file")));
        echo "
                            </div>
                        </div>
                        <div class=\"form-group col-lg-11\">
                            ";
        // line 54
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "image"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Image: "));
        echo "
                            <div class=\"col-sm-2\">
                            <img src=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/products/", 1 => $this->getContext($context, "id"), 2 => "/", 3 => $this->getContext($context, "image")))), "html", null, true);
        echo "\" style=\"width:80px; height: 50px;\"/>
                            </div>
                        </div>    
                        <div class=\"form-group col-lg-12\">
                            <div class=\"control-label col-sm-2\"></div>
                            <div class=\"col-sm-2\">
                            <input type=\"submit\" name=\"edit\" value=\"Save\" class=\"btn btn-primary\">
                            <input type=\"reset\" name=\"Reset\" value=\"Reset\" class=\"btn btn-danger\" onclick=\"javascript:window.location.href='";
        // line 63
        echo $this->env->getExtension('routing')->getPath("acme_store");
        echo "'\"/>
                            </div>
                        </div>
                    </form>
\t\t</center>
\t\t</div>
";
    }

    public function getTemplateName()
    {
        return "AcmeStoreBundle:Default:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  155 => 63,  145 => 56,  140 => 54,  133 => 50,  128 => 48,  121 => 44,  116 => 42,  109 => 38,  104 => 36,  97 => 32,  92 => 30,  85 => 26,  80 => 24,  77 => 23,  71 => 20,  67 => 19,  63 => 18,  59 => 17,  56 => 16,  53 => 15,  49 => 13,  38 => 4,  32 => 3,  29 => 2,);
    }
}
