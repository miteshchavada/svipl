<?php

/* AcmeStoreBundle:Default:edit.html.twig */
class __TwigTemplate_e15daaa8fbf0c20dc674cbc0db9b26acff7facf3174ff8f7329befdd020adeb6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        $this->displayBlock('content', $context, $blocks);
    }

    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <h1 class=\"page-header\">Edit Product</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class=\"row\">
                <center>
                    <form action=\"";
        // line 13
        if (isset($context["id"])) { $_id_ = $context["id"]; } else { $_id_ = null; }
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("edit", array("id" => $_id_)), "html", null, true);
        echo "\" method=\"post\" id=\"form\" enctype=\"multipart/form-data\" name=\"form\" class=\"form-group\" novalidate=\"novalidate\">
";
        // line 15
        echo "                        ";
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        if ((!$this->getAttribute($this->getAttribute($_form_, "vars"), "valid"))) {
            // line 16
            echo "                        <div class=\"alert alert-danger\">    
\t\t\t\t";
            // line 17
            if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "name"), 'errors');
            echo "
\t\t\t\t";
            // line 18
            if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "price"), 'errors');
            echo "
\t\t\t\t";
            // line 19
            if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "description"), 'errors');
            echo "
                                ";
            // line 20
            if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "image"), 'errors');
            echo "
                        </div>
                        ";
        }
        // line 23
        echo "                        <div class=\"form-group col-lg-12\">
                            ";
        // line 24
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "name"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Name: "));
        echo "
                            <div class=\"col-sm-10\">
                              ";
        // line 26
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "name"), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Product Name", "value" => $this->getAttribute($_product_, "name"))));
        echo "  
                            </div>
                        </div>
                        <div class=\"form-group col-lg-12\">
                            ";
        // line 30
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "price"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Price: "));
        echo "
                            <div class=\"col-sm-10\">
                            ";
        // line 32
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "price"), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Price", "value" => $this->getAttribute($_product_, "price"))));
        echo "
                            </div>
                        </div>
                        <div class=\"form-group col-lg-12\">
                            ";
        // line 36
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "description"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Description: "));
        echo "
                            <div class=\"col-sm-10\">
                            ";
        // line 38
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "description"), 'widget', array("value" => $this->getAttribute($_product_, "description"), "attr" => array("class" => "form-control")));
        echo "
                            </div>
                        </div>
                        <div class=\"form-group col-lg-12\">
                            ";
        // line 42
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "image"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "File: "));
        echo "
                            <div class=\"col-sm-2\">
                                ";
        // line 44
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "image"), 'widget', array("attr" => array("class" => "btn btn-default btn-file")));
        echo "
                            </div>
                        </div>
                        <div class=\"form-group col-lg-11\">
                            ";
        // line 48
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "image"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Image: "));
        echo "
                            <div class=\"col-sm-2\">
                            <img src=\"";
        // line 50
        if (isset($context["id"])) { $_id_ = $context["id"]; } else { $_id_ = null; }
        if (isset($context["image"])) { $_image_ = $context["image"]; } else { $_image_ = null; }
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/products/", 1 => $_id_, 2 => "/", 3 => $_image_))), "html", null, true);
        echo "\" style=\"width:80px; height: 50px;\"/>
                            </div>
                        </div>    
                        <div class=\"form-group col-lg-12\">
                            <div class=\"control-label col-sm-2\"></div>
                            <div class=\"col-sm-2\">
                            <input type=\"submit\" name=\"edit\" value=\"Save\" class=\"btn btn-primary\">
                            <input type=\"reset\" name=\"Reset\" value=\"Reset\" class=\"btn btn-danger\" onclick=\"javascript:window.location.href='";
        // line 57
        echo $this->env->getExtension('routing')->getPath("acme_store");
        echo "'\"/>
                            </div>
                        </div>
                    </form>
\t\t</center>
\t\t</div>
";
    }

    public function getTemplateName()
    {
        return "AcmeStoreBundle:Default:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 48,  86 => 24,  83 => 23,  206 => 201,  200 => 198,  188 => 192,  179 => 185,  177 => 184,  174 => 183,  159 => 86,  151 => 50,  135 => 80,  99 => 59,  165 => 51,  139 => 81,  126 => 43,  95 => 36,  91 => 31,  87 => 34,  23 => 3,  128 => 46,  116 => 36,  79 => 17,  61 => 17,  20 => 1,  42 => 10,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 78,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 66,  143 => 82,  138 => 44,  134 => 49,  131 => 42,  122 => 38,  117 => 36,  108 => 31,  102 => 28,  92 => 26,  84 => 31,  72 => 15,  48 => 13,  35 => 5,  29 => 2,  69 => 33,  54 => 15,  51 => 21,  31 => 4,  312 => 96,  308 => 94,  293 => 92,  285 => 90,  281 => 88,  277 => 86,  274 => 85,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 73,  204 => 69,  198 => 65,  194 => 195,  150 => 54,  147 => 83,  127 => 41,  112 => 19,  96 => 33,  76 => 20,  71 => 19,  39 => 12,  110 => 39,  89 => 16,  65 => 23,  63 => 12,  58 => 16,  34 => 4,  55 => 15,  26 => 11,  24 => 6,  43 => 7,  114 => 22,  109 => 63,  106 => 17,  101 => 30,  85 => 28,  77 => 12,  67 => 19,  28 => 3,  227 => 92,  224 => 91,  221 => 90,  207 => 70,  197 => 74,  195 => 65,  192 => 72,  189 => 61,  186 => 60,  181 => 67,  178 => 61,  173 => 58,  162 => 58,  158 => 56,  155 => 85,  152 => 40,  142 => 52,  136 => 44,  133 => 43,  130 => 42,  120 => 40,  105 => 38,  100 => 37,  75 => 23,  60 => 12,  53 => 10,  57 => 24,  50 => 7,  47 => 8,  38 => 4,  25 => 3,  19 => 1,  98 => 40,  88 => 33,  80 => 15,  78 => 25,  46 => 12,  44 => 8,  40 => 16,  36 => 15,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 76,  215 => 204,  211 => 203,  208 => 70,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 62,  180 => 59,  171 => 54,  166 => 51,  163 => 57,  160 => 49,  157 => 48,  149 => 48,  146 => 41,  140 => 52,  137 => 44,  129 => 44,  124 => 20,  121 => 42,  118 => 41,  115 => 66,  111 => 32,  107 => 32,  104 => 61,  97 => 34,  93 => 32,  90 => 35,  81 => 26,  70 => 23,  66 => 18,  62 => 11,  59 => 15,  56 => 12,  52 => 11,  49 => 13,  45 => 18,  41 => 5,  37 => 5,  33 => 3,  30 => 1,);
    }
}
