<?php

/* AcmeHomeBundle:Default:products.html.twig */
class __TwigTemplate_e967c9347f21b3e1d968f6ad4118a88c51021ace4af3d6a28d572ddb93e569f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::common.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::common.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"body3\">
\t\t<div class=\"main zerogrid\">
<!-- content -->
\t\t\t<article id=\"content\">
                                <div class=\"wrapper\">
                                    ";
        // line 8
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "products"));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 9
            echo "                                        <section class=\"col-1-3\">
\t\t\t\t\t<div class=\"wrap-col\">
\t\t\t\t\t\t<div class=\"wrapper pad_bot2\">
\t\t\t\t\t\t\t<h3><span class=\"dropcap\">";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "loop"), "index"), "html", null, true);
            echo "</span>";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "name"), "html", null, true);
            echo "</h3>
\t\t\t\t\t\t\t<figure><img src=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/products/", 1 => $this->getAttribute($this->getContext($context, "product"), "id"), 2 => "/", 3 => $this->getAttribute($this->getContext($context, "product"), "image")))), "html", null, true);
            echo "\" alt=\"\"></figure>
\t\t\t\t\t\t\t<p class=\"pad_bot1\" id=\"desc_";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "id"), "html", null, true);
            echo "\" style=\"display:block;\">";
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($this->getContext($context, "product"), "description"), 0, 50), "html", null, true);
            echo "</p>
                            \t\t\t\t<p class=\"pad_bot1\" id=\"pname_";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "id"), "html", null, true);
            echo "\" style=\"display:none;\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "description"), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t<a href=\"Javascript:toggle('pname_";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "id"), "html", null, true);
            echo "','desc_";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "id"), "html", null, true);
            echo "');\" class=\"link1\">Read More</a>
\t\t\t\t\t\t\t<a href=\"/products/cart?id=";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "id"), "html", null, true);
            echo "\">Add To Cart</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t</section>
                                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "                                </div>
\t\t\t</article>
\t\t</div>
\t</div>
\t";
        // line 26
        echo twig_include($this->env, $context, "followUs.html.twig");
        echo "
        ";
        // line 27
        echo twig_include($this->env, $context, "footer.html.twig");
        echo "
<script type=\"text/javascript\"> Cufon.now(); </script>
<script>
\t\$(document).ready(function() {
\t\ttabs.init();
\t})
</script>
<script type=\"text/javascript\">
function toggle(obj,obj1) {

  var toggle = document.getElementById(obj);
  var desc = document.getElementById(obj1);
  
  if (toggle.style.display != \"none\") {
    toggle.style.display = \"none\";
    desc.style.display = \"block\";
  }
  else {
    toggle.style.display = \"block\";
    desc.style.display = \"none\";
  }
}
</script>
";
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle:Default:products.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 27,  113 => 26,  107 => 22,  88 => 17,  82 => 16,  76 => 15,  70 => 14,  66 => 13,  60 => 12,  55 => 9,  38 => 8,  31 => 3,  28 => 2,);
    }
}
