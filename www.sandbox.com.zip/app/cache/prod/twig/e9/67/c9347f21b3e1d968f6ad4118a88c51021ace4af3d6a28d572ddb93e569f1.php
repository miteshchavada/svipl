<?php

/* AcmeHomeBundle:Default:products.html.twig */
class __TwigTemplate_e967c9347f21b3e1d968f6ad4118a88c51021ace4af3d6a28d572ddb93e569f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::common.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::common.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "<div class=\"body3\">
\t\t<div class=\"main zerogrid\">
<!-- content -->
\t\t\t<article id=\"content\">
                                <div class=\"wrapper\">
                                    ";
        // line 8
        if (isset($context["products"])) { $_products_ = $context["products"]; } else { $_products_ = null; }
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($_products_);
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 9
            echo "                                        <section class=\"col-1-3\">
\t\t\t\t\t<div class=\"wrap-col\">
\t\t\t\t\t\t<div class=\"wrapper pad_bot2\">
\t\t\t\t\t\t\t<h3><span class=\"dropcap\">";
            // line 12
            if (isset($context["loop"])) { $_loop_ = $context["loop"]; } else { $_loop_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_loop_, "index"), "html", null, true);
            echo "</span>";
            if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_product_, "name"), "html", null, true);
            echo "</h3>
\t\t\t\t\t\t\t<figure><img src=\"";
            // line 13
            if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/products/", 1 => $this->getAttribute($_product_, "id"), 2 => "/", 3 => $this->getAttribute($_product_, "image")))), "html", null, true);
            echo "\" alt=\"\"></figure>
\t\t\t\t\t\t\t<p class=\"pad_bot1\" id=\"desc_";
            // line 14
            if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_product_, "id"), "html", null, true);
            echo "\" style=\"display:block;\">";
            if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($_product_, "description"), 0, 50), "html", null, true);
            echo "</p>
                            \t\t\t\t<p class=\"pad_bot1\" id=\"pname_";
            // line 15
            if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_product_, "id"), "html", null, true);
            echo "\" style=\"display:none;\">";
            if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_product_, "description"), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t<a href=\"Javascript:toggle('pname_";
            // line 16
            if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_product_, "id"), "html", null, true);
            echo "','desc_";
            if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_product_, "id"), "html", null, true);
            echo "');\" class=\"link1\">Read More</a>
\t\t\t\t\t\t\t<a href=\"/products/cart?id=";
            // line 17
            if (isset($context["product"])) { $_product_ = $context["product"]; } else { $_product_ = null; }
            echo twig_escape_filter($this->env, $this->getAttribute($_product_, "id"), "html", null, true);
            echo "\">Add To Cart</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t</section>
                                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "                                </div>
\t\t\t</article>
\t\t</div>
\t</div>
\t";
        // line 26
        echo twig_include($this->env, $context, "followUs.html.twig");
        echo "
        ";
        // line 27
        echo twig_include($this->env, $context, "footer.html.twig");
        echo "
<script type=\"text/javascript\"> Cufon.now(); </script>
<script>
\t\$(document).ready(function() {
\t\ttabs.init();
\t})
</script>
<script type=\"text/javascript\">
function toggle(obj,obj1) {

  var toggle = document.getElementById(obj);
  var desc = document.getElementById(obj1);
  
  if (toggle.style.display != \"none\") {
    toggle.style.display = \"none\";
    desc.style.display = \"block\";
  }
  else {
    toggle.style.display = \"block\";
    desc.style.display = \"none\";
  }
}
</script>
";
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle:Default:products.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 14,  311 => 116,  270 => 26,  266 => 25,  262 => 24,  258 => 23,  254 => 22,  250 => 21,  246 => 20,  242 => 19,  238 => 18,  233 => 17,  230 => 16,  220 => 13,  216 => 12,  212 => 11,  203 => 9,  172 => 106,  144 => 94,  141 => 93,  82 => 15,  176 => 49,  153 => 35,  148 => 34,  125 => 23,  68 => 12,  145 => 48,  86 => 21,  83 => 20,  206 => 201,  200 => 8,  188 => 117,  179 => 111,  177 => 184,  174 => 183,  159 => 86,  151 => 50,  135 => 80,  99 => 59,  165 => 101,  139 => 81,  126 => 43,  95 => 36,  91 => 31,  87 => 34,  23 => 2,  128 => 27,  116 => 36,  79 => 17,  61 => 12,  20 => 1,  42 => 10,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 29,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 66,  143 => 46,  138 => 30,  134 => 41,  131 => 42,  122 => 38,  117 => 36,  108 => 81,  102 => 28,  92 => 76,  84 => 14,  72 => 70,  48 => 12,  35 => 5,  29 => 6,  69 => 13,  54 => 12,  51 => 21,  31 => 3,  312 => 96,  308 => 94,  293 => 40,  285 => 90,  281 => 88,  277 => 86,  274 => 27,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 73,  204 => 69,  198 => 65,  194 => 6,  150 => 98,  147 => 83,  127 => 41,  112 => 19,  96 => 33,  76 => 71,  71 => 16,  39 => 54,  110 => 20,  89 => 16,  65 => 23,  63 => 12,  58 => 13,  34 => 8,  55 => 12,  26 => 11,  24 => 6,  43 => 7,  114 => 83,  109 => 63,  106 => 18,  101 => 30,  85 => 25,  77 => 12,  67 => 17,  28 => 2,  227 => 92,  224 => 14,  221 => 90,  207 => 70,  197 => 74,  195 => 65,  192 => 72,  189 => 61,  186 => 116,  181 => 67,  178 => 61,  173 => 58,  162 => 58,  158 => 56,  155 => 99,  152 => 40,  142 => 32,  136 => 90,  133 => 29,  130 => 88,  120 => 85,  105 => 38,  100 => 37,  75 => 23,  60 => 66,  53 => 10,  57 => 65,  50 => 7,  47 => 11,  38 => 8,  25 => 3,  19 => 1,  98 => 17,  88 => 75,  80 => 15,  78 => 25,  46 => 12,  44 => 8,  40 => 16,  36 => 16,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 76,  215 => 204,  211 => 203,  208 => 10,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 62,  180 => 50,  171 => 54,  166 => 51,  163 => 38,  160 => 49,  157 => 48,  149 => 48,  146 => 41,  140 => 52,  137 => 44,  129 => 44,  124 => 26,  121 => 42,  118 => 22,  115 => 21,  111 => 32,  107 => 32,  104 => 80,  97 => 34,  93 => 32,  90 => 16,  81 => 25,  70 => 18,  66 => 68,  62 => 11,  59 => 15,  56 => 9,  52 => 11,  49 => 62,  45 => 18,  41 => 5,  37 => 5,  33 => 3,  30 => 1,);
    }
}
