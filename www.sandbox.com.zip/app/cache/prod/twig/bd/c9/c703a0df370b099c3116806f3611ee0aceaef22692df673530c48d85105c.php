<?php

/* AcmeHomeBundle:Default:login.html.twig */
class __TwigTemplate_bdc9c703a0df370b099c3116806f3611ee0aceaef22692df673530c48d85105c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::common.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::common.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"body3\">
        <div class=\"main zerogrid\">
            <!-- content -->
            <article id=\"content\">
                <div class=\"wrapper row\">
                    <section class=\"col-3-4\">
                        <div class=\"wrap-col\">
                            <h2 class=\"under\">Login Form</h2>
                            ";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "session"), "flashbag"), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 12
            echo "                                <div class=\"flash notice\">
                                    ";
            // line 13
            echo twig_escape_filter($this->env, $this->getContext($context, "flashMessage"), "html", null, true);
            echo "
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "                            <form action=\"";
        echo $this->env->getExtension('routing')->getPath("fos_user_security_check");
        echo "\" method=\"post\">
                            ";
        // line 17
        if ($this->getContext($context, "error")) {
            // line 18
            echo "                                <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getContext($context, "error"), array(), "FOSUserBundle"), "html", null, true);
            echo "</div>
                            ";
        }
        // line 20
        echo "                            <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        echo twig_escape_filter($this->env, $this->getContext($context, "csrf_token"), "html", null, true);
        echo "\" />
                                <fieldset>
                                        <label for=\"username\">";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("security.login.username", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                                        <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->getContext($context, "last_username"), "html", null, true);
        echo "\" required=\"required\" class=\"form-control\"/>
                                    
                                        <label for=\"password\">";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("security.login.password", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                                        <input type=\"password\" id=\"password\" name=\"_password\" required=\"required\" class=\"form-control\"/>
                                        
                                        <label>
                                            <input name=\"remember\" type=\"checkbox\" value=\"on\" id=\"remember_me\">Remember Me
                                        </label>
                                    <input type=\"submit\" class=\"btn btn-lg btn-success btn-block\" id=\"_submit\" name=\"_submit\" value=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("security.login.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "\" />                                </fieldset>
                            </form>
                        </div>
                    </section>
                </div>

            </article>
        </div>
    </div>
    ";
        // line 40
        echo twig_include($this->env, $context, "followUs.html.twig");
        echo "
    ";
        // line 41
        echo twig_include($this->env, $context, "footer.html.twig");
        echo "
    <script type=\"text/javascript\"> Cufon.now();</script>
    <script>
        \$(document).ready(function () {
            tabs.init();
        })
    </script>
";
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle:Default:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 41,  106 => 40,  94 => 31,  85 => 25,  80 => 23,  76 => 22,  70 => 20,  64 => 18,  62 => 17,  57 => 16,  48 => 13,  45 => 12,  41 => 11,  31 => 3,  28 => 2,);
    }
}
