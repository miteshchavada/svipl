<?php

/* ::newsletter.html.twig */
class __TwigTemplate_41bb8a5efd3e6314e899be0dd9fca6def3a1ab82d48740631c95b1b22d37d697 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if (isset($context["app"])) { $_app_ = $context["app"]; } else { $_app_ = null; }
        if (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "acme_home")) {
            // line 2
            echo "    ";
            $context["foo"] = "acme_home";
        } elseif (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "news")) {
            // line 4
            echo "    ";
            $context["foo"] = "news";
        } elseif (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "services")) {
            // line 6
            echo "    ";
            $context["foo"] = "services";
        } elseif (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "products")) {
            // line 8
            echo "    ";
            $context["foo"] = "products";
        } elseif (($this->getAttribute($this->getAttribute($_app_, "request"), "get", array(0 => "_route"), "method") == "contact")) {
            // line 10
            echo "    ";
            $context["foo"] = "contact";
        }
        // line 12
        echo "<form action=\"";
        if (isset($context["foo"])) { $_foo_ = $context["foo"]; } else { $_foo_ = null; }
        echo $this->env->getExtension('routing')->getPath($_foo_);
        echo "\" method=\"post\" ";
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($_form_, 'enctype');
        echo " id=\"newsletter\">
    <div style=\"color:red;\">";
        // line 13
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "email"), 'errors');
        echo "</div>
    <div>
        <div class=\"wrapper\">
            ";
        // line 16
        if (isset($context["form"])) { $_form_ = $context["form"]; } else { $_form_ = null; }
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($_form_, "email"), 'widget', array("attr" => array("onfocus" => "if(this.value ==\"Type Your Email Here\" ) this.value=\"\"", "onblur" => "if(this.value==\"\") this.value=\"Type Your Email Here\"", "value" => "", "class" => "input")));
        echo "
        </div>
        <input type=\"submit\" formnovalidate value=\"Subscribe\" name=\"insert\"/>
        <!--a href=\"#\" name=\"subscribe\" class=\"button\" onclick=\"document.getElementById('newsletter').submit()\">Subscribe</a-->
    </div>
</form>
";
    }

    public function getTemplateName()
    {
        return "::newsletter.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 40,  113 => 34,  119 => 40,  103 => 36,  132 => 42,  94 => 35,  64 => 15,  182 => 43,  217 => 22,  213 => 21,  209 => 20,  205 => 19,  175 => 11,  73 => 52,  74 => 20,  311 => 116,  270 => 26,  266 => 25,  262 => 24,  258 => 23,  254 => 22,  250 => 21,  246 => 20,  242 => 19,  238 => 18,  233 => 17,  230 => 16,  220 => 13,  216 => 12,  212 => 11,  203 => 9,  172 => 38,  144 => 94,  141 => 45,  82 => 25,  176 => 49,  153 => 35,  148 => 34,  125 => 40,  68 => 32,  145 => 48,  86 => 33,  83 => 55,  206 => 201,  200 => 8,  188 => 117,  179 => 12,  177 => 184,  174 => 183,  159 => 86,  151 => 36,  135 => 43,  99 => 36,  165 => 101,  139 => 81,  126 => 43,  95 => 26,  91 => 31,  87 => 22,  23 => 2,  128 => 32,  116 => 36,  79 => 20,  61 => 14,  20 => 1,  42 => 12,  549 => 162,  543 => 161,  538 => 158,  530 => 155,  526 => 153,  522 => 151,  512 => 149,  505 => 148,  502 => 147,  497 => 146,  491 => 144,  488 => 143,  483 => 142,  473 => 134,  469 => 132,  466 => 131,  460 => 130,  455 => 129,  450 => 126,  444 => 122,  441 => 121,  437 => 120,  434 => 119,  429 => 116,  423 => 112,  420 => 111,  416 => 110,  413 => 109,  408 => 106,  394 => 105,  390 => 103,  375 => 101,  365 => 99,  362 => 98,  359 => 97,  355 => 95,  348 => 91,  344 => 90,  330 => 89,  327 => 88,  321 => 86,  307 => 85,  302 => 84,  295 => 81,  287 => 80,  279 => 29,  256 => 73,  251 => 71,  239 => 69,  231 => 68,  219 => 67,  201 => 18,  143 => 46,  138 => 46,  134 => 44,  131 => 70,  122 => 38,  117 => 36,  108 => 37,  102 => 35,  92 => 33,  84 => 31,  72 => 32,  48 => 11,  35 => 6,  29 => 5,  69 => 16,  54 => 12,  51 => 13,  31 => 3,  312 => 96,  308 => 94,  293 => 40,  285 => 90,  281 => 88,  277 => 86,  274 => 27,  271 => 77,  264 => 74,  261 => 81,  257 => 79,  253 => 77,  249 => 76,  247 => 70,  237 => 81,  204 => 69,  198 => 65,  194 => 6,  150 => 98,  147 => 83,  127 => 40,  112 => 33,  96 => 33,  76 => 19,  71 => 16,  39 => 4,  110 => 39,  89 => 34,  65 => 23,  63 => 16,  58 => 16,  34 => 8,  55 => 12,  26 => 4,  24 => 6,  43 => 10,  114 => 39,  109 => 32,  106 => 17,  101 => 28,  85 => 22,  77 => 53,  67 => 50,  28 => 2,  227 => 92,  224 => 14,  221 => 90,  207 => 70,  197 => 17,  195 => 65,  192 => 16,  189 => 15,  186 => 116,  181 => 67,  178 => 42,  173 => 58,  162 => 58,  158 => 56,  155 => 99,  152 => 40,  142 => 32,  136 => 90,  133 => 35,  130 => 88,  120 => 85,  105 => 62,  100 => 25,  75 => 20,  60 => 15,  53 => 12,  57 => 15,  50 => 13,  47 => 9,  38 => 10,  25 => 3,  19 => 1,  98 => 29,  88 => 75,  80 => 15,  78 => 19,  46 => 12,  44 => 8,  40 => 10,  36 => 4,  32 => 3,  27 => 2,  22 => 2,  232 => 184,  226 => 71,  222 => 24,  215 => 204,  211 => 203,  208 => 10,  202 => 68,  196 => 64,  193 => 63,  187 => 62,  183 => 13,  180 => 50,  171 => 10,  166 => 9,  163 => 8,  160 => 49,  157 => 6,  149 => 81,  146 => 41,  140 => 48,  137 => 45,  129 => 42,  124 => 39,  121 => 38,  118 => 35,  115 => 34,  111 => 32,  107 => 32,  104 => 37,  97 => 34,  93 => 26,  90 => 33,  81 => 20,  70 => 20,  66 => 15,  62 => 14,  59 => 14,  56 => 13,  52 => 10,  49 => 13,  45 => 11,  41 => 8,  37 => 5,  33 => 3,  30 => 6,);
    }
}
