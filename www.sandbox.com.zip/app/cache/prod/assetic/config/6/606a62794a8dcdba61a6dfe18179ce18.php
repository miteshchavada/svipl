<?php

// :Emails:registration.html.twig
return array (
);
