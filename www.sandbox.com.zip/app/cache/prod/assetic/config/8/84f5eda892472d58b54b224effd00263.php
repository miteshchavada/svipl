<?php

// ::newsletter.html.twig
return array (
);
