<?php

/* followUs.html.twig */
class __TwigTemplate_11cac73db283dc4c5198da5475307e357748fb85d4b12d8b24b89a7e5025f4ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"body4\">
    <div class=\"main zerogrid\">
        <article id=\"content2\">
            <div class=\"wrapper row\">
                <section class=\"col-1-4\">
                    <div class=\"wrap-col\">
                        <h4>Why Us?</h4>
                        <ul class=\"list1\">
                            <li><a href=\"#\">Lorem ipsum dolor sit</a></li>
                            <li><a href=\"#\">Dmet, consectetur</a></li>
                            <li><a href=\"#\">Adipisicing elit eiusmod </a></li>
                            <li><a href=\"#\">Tempor incididunt ut</a></li>
                        </ul>
                    </div>
                </section>
                <section class=\"col-1-4\">
                    <div class=\"wrap-col\">
                        <h4>Address</h4>
                        <ul class=\"address\">
                            <li><span>Country:</span>USA</li>
                            <li><span>City:</span>San Diego</li>
                            <li><span>Phone:</span>8 800 154-45-67</li>
                            <li><span>Email:</span><a href=\"mailto:\">progress@mail.com</a></li>
                        </ul>
                    </div>
                </section>
                <section class=\"col-1-4\">
                    <div class=\"wrap-col\">
                        <h4>Follow Us</h4>
                        <ul id=\"icons\">
                            <li><a href=\"https://www.facebook.com/siddhivinayak.svipl\"><img src=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("/bundles/acmehome/images/icon1.jpg"), "html", null, true);
        echo "\" alt=\"\">Facebook</a></li>
                            <li><a href=\"https://twitter.com/sviplfive\"><img src=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("/bundles/acmehome/images/icon2.jpg"), "html", null, true);
        echo "\" alt=\"\">Twitter</a></li>
                            <li><a href=\"https://www.linkedin.com/company/siddhi-vinayak-infocom-pvt.-ltd.-rajkot-gujarat\"><img src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("/bundles/acmehome/images/icon3.jpg"), "html", null, true);
        echo "\" alt=\"\">LinkedIn</a></li>
                            <li><a href=\"#\"><img src=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("/bundles/acmehome/images/icon4.jpg"), "html", null, true);
        echo "\" alt=\"\">Delicious</a></li>
                        </ul>
                    </div>
                </section>
                <section class=\"col-1-4\">
                    <div class=\"wrap-col\">
                        <h4>Newsletter</h4>
                        <form id=\"newsletter\" method=\"post\">
                            <div>
                                <div class=\"wrapper\">
                                    <input class=\"input\" type=\"text\" value=\"Type Your Email Here\"  onblur=\"if (this.value == '')
                                                this.value = 'Type Your Email Here'\" onfocus=\"if (this.value == 'Type Your Email Here')
                                                            this.value = ''\" >
                                </div>
                                <a href=\"#\" class=\"button\" onclick=\"document.getElementById('newsletter').submit()\">Subscribe</a>
                            </div>
                        </form>
                    </div>
                </section>
            </div>
        </article>
        <!-- content end -->
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "followUs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 34,  51 => 31,  19 => 1,  303 => 116,  285 => 40,  271 => 29,  266 => 27,  262 => 26,  258 => 25,  254 => 24,  250 => 23,  246 => 22,  242 => 21,  238 => 20,  234 => 19,  230 => 18,  225 => 17,  222 => 16,  216 => 14,  212 => 13,  208 => 12,  204 => 11,  200 => 10,  195 => 9,  192 => 8,  186 => 6,  180 => 117,  178 => 116,  171 => 111,  164 => 106,  157 => 101,  144 => 98,  138 => 94,  136 => 93,  131 => 90,  125 => 88,  119 => 86,  116 => 85,  110 => 83,  104 => 81,  95 => 78,  89 => 76,  86 => 75,  80 => 73,  74 => 71,  57 => 65,  49 => 62,  39 => 54,  36 => 16,  34 => 8,  29 => 6,  23 => 2,  165 => 50,  161 => 49,  148 => 99,  139 => 35,  135 => 34,  130 => 32,  126 => 30,  122 => 29,  114 => 23,  105 => 21,  101 => 80,  97 => 18,  77 => 14,  71 => 70,  65 => 68,  59 => 33,  55 => 32,  38 => 8,  31 => 3,  28 => 2,);
    }
}
