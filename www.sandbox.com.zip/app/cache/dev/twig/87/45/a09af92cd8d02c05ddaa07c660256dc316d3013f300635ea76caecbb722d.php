<?php

/* WebProfilerBundle:Collector:exception.css.twig */
class __TwigTemplate_8745a09af92cd8d02c05ddaa07c660256dc316d3013f300635ea76caecbb722d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo ".sf-reset .traces {
    padding-bottom: 14px;
}
.sf-reset .traces li {
    font-size: 12px;
    color: #868686;
    padding: 5px 4px;
    list-style-type: decimal;
    margin-left: 20px;
    white-space: break-word;
}
.sf-reset #logs .traces li.error {
    font-style: normal;
    color: #AA3333;
    background: #f9ecec;
}
.sf-reset #logs .traces li.warning {
    font-style: normal;
    background: #ffcc00;
}
/* fix for Opera not liking empty <li> */
.sf-reset .traces li:after {
    content: \"\\00A0\";
}
.sf-reset .trace {
    border: 1px solid #D3D3D3;
    padding: 10px;
    overflow: auto;
    margin: 10px 0 20px;
}
.sf-reset .block-exception {
    border-radius: 16px;
    margin-bottom: 20px;
    background-color: #f6f6f6;
    border: 1px solid #dfdfdf;
    padding: 30px 28px;
    word-wrap: break-word;
    overflow: hidden;
}
.sf-reset .block-exception div {
    color: #313131;
    font-size: 10px;
}
.sf-reset .block-exception-detected .illustration-exception,
.sf-reset .block-exception-detected .text-exception {
    float: left;
}
.sf-reset .block-exception-detected .illustration-exception {
    width: 152px;
}
.sf-reset .block-exception-detected .text-exception {
    width: 670px;
    padding: 30px 44px 24px 46px;
    position: relative;
}
.sf-reset .text-exception .open-quote,
.sf-reset .text-exception .close-quote {
    position: absolute;
}
.sf-reset .open-quote {
    top: 0;
    left: 0;
}
.sf-reset .close-quote {
    bottom: 0;
    right: 50px;
}
.sf-reset .block-exception p {
    font-family: Arial, Helvetica, sans-serif;
}
.sf-reset .block-exception p a,
.sf-reset .block-exception p a:hover {
    color: #565656;
}
.sf-reset .logs h2 {
    float: left;
    width: 654px;
}
.sf-reset .error-count {
    float: right;
    width: 170px;
    text-align: right;
}
.sf-reset .error-count span {
    display: inline-block;
    background-color: #aacd4e;
    border-radius: 6px;
    padding: 4px;
    color: white;
    margin-right: 2px;
    font-size: 11px;
    font-weight: bold;
}
.sf-reset .toggle {
    vertical-align: middle;
}
.sf-reset .linked ul,
.sf-reset .linked li {
    display: inline;
}
.sf-reset #output-content {
    color: #000;
    font-size: 12px;
}
";
    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:exception.css.twig";
    }

    public function getDebugInfo()
    {
        return array (  191 => 77,  188 => 76,  185 => 75,  167 => 71,  153 => 69,  127 => 60,  124 => 46,  100 => 32,  160 => 42,  232 => 81,  184 => 15,  174 => 74,  170 => 11,  90 => 32,  81 => 22,  303 => 116,  271 => 29,  266 => 27,  262 => 26,  250 => 23,  242 => 21,  234 => 19,  225 => 17,  222 => 16,  216 => 14,  212 => 22,  200 => 19,  195 => 9,  192 => 17,  186 => 6,  180 => 117,  165 => 50,  161 => 9,  148 => 99,  76 => 31,  104 => 42,  231 => 184,  210 => 203,  205 => 201,  178 => 13,  150 => 84,  146 => 82,  134 => 54,  152 => 6,  114 => 40,  110 => 22,  97 => 41,  126 => 48,  118 => 49,  77 => 17,  65 => 16,  58 => 17,  84 => 29,  23 => 2,  34 => 8,  129 => 46,  113 => 48,  70 => 17,  53 => 10,  20 => 1,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 40,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 25,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 204,  177 => 65,  169 => 60,  140 => 55,  132 => 71,  128 => 43,  107 => 38,  61 => 12,  273 => 96,  269 => 94,  254 => 24,  243 => 88,  240 => 86,  238 => 20,  235 => 74,  230 => 18,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 24,  208 => 21,  204 => 78,  179 => 69,  159 => 61,  143 => 57,  135 => 62,  119 => 86,  102 => 41,  71 => 19,  67 => 24,  63 => 19,  59 => 13,  87 => 34,  38 => 6,  26 => 9,  94 => 34,  89 => 33,  85 => 32,  75 => 21,  68 => 32,  56 => 11,  201 => 92,  196 => 18,  183 => 82,  171 => 73,  166 => 10,  163 => 62,  158 => 79,  156 => 66,  151 => 63,  142 => 82,  138 => 56,  136 => 93,  121 => 50,  117 => 19,  105 => 18,  91 => 28,  62 => 15,  49 => 14,  31 => 3,  28 => 3,  24 => 6,  25 => 35,  21 => 2,  19 => 1,  93 => 28,  88 => 31,  78 => 26,  46 => 13,  44 => 11,  27 => 3,  79 => 22,  72 => 32,  69 => 19,  47 => 8,  40 => 6,  37 => 5,  22 => 2,  246 => 22,  157 => 101,  145 => 46,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 40,  111 => 47,  108 => 19,  101 => 43,  98 => 32,  96 => 37,  83 => 33,  74 => 27,  66 => 30,  55 => 16,  52 => 14,  50 => 13,  43 => 12,  41 => 10,  35 => 6,  32 => 5,  29 => 3,  209 => 82,  203 => 78,  199 => 198,  193 => 195,  189 => 71,  187 => 16,  182 => 66,  176 => 184,  173 => 183,  168 => 72,  164 => 70,  162 => 168,  154 => 38,  149 => 51,  147 => 40,  144 => 81,  141 => 48,  133 => 50,  130 => 45,  125 => 51,  122 => 29,  116 => 40,  112 => 40,  109 => 40,  106 => 45,  103 => 34,  99 => 34,  95 => 34,  92 => 35,  86 => 26,  82 => 28,  80 => 32,  73 => 16,  64 => 23,  60 => 15,  57 => 12,  54 => 12,  51 => 12,  48 => 9,  45 => 8,  42 => 7,  39 => 4,  36 => 5,  33 => 4,  30 => 3,);
    }
}
