<?php

/* AcmeHomeBundle::layout.html.twig */
class __TwigTemplate_5feb6f9d89951086d86a9d3ba68355ac629a43de06cd6711275352dddf3b54a0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("TwigBundle::layout.html.twig");

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content_header' => array($this, 'block_content_header'),
            'content_header_more' => array($this, 'block_content_header_more'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        // line 4
        echo "    <link rel=\"icon\" sizes=\"16x16\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/css/demo.css"), "html", null, true);
        echo "\" />
";
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        echo "Demo Bundle";
    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        echo "\t
    ";
        // line 11
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "session"), "flashbag"), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 12
            echo "        <div class=\"flash-message\">
            <em>Notice</em>: ";
            // line 13
            echo twig_escape_filter($this->env, $this->getContext($context, "flashMessage"), "html", null, true);
            echo "
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "
    ";
        // line 17
        $this->displayBlock('content_header', $context, $blocks);
        // line 26
        echo "
    <div class=\"block\">
        ";
        // line 28
        $this->displayBlock('content', $context, $blocks);
        // line 29
        echo "    </div>

    ";
        // line 31
        if (array_key_exists("code", $context)) {
            // line 32
            echo "        <h2>Code behind this page</h2>
        <div class=\"block\">
            <div class=\"symfony-content\">";
            // line 34
            echo $this->getContext($context, "code");
            echo "</div>
        </div>
    ";
        }
    }

    // line 17
    public function block_content_header($context, array $blocks = array())
    {
        // line 18
        echo "        <ul id=\"menu\">
            ";
        // line 19
        $this->displayBlock('content_header_more', $context, $blocks);
        // line 22
        echo "        </ul>

        <div style=\"clear: both\"></div>
    ";
    }

    // line 19
    public function block_content_header_more($context, array $blocks = array())
    {
        // line 20
        echo "                
            ";
    }

    // line 28
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  160 => 42,  232 => 81,  184 => 15,  174 => 12,  170 => 11,  90 => 25,  81 => 28,  303 => 116,  271 => 29,  266 => 27,  262 => 26,  250 => 23,  242 => 21,  234 => 19,  225 => 17,  222 => 16,  216 => 14,  212 => 22,  200 => 19,  195 => 9,  192 => 17,  186 => 6,  180 => 117,  165 => 50,  161 => 9,  148 => 99,  76 => 15,  104 => 49,  231 => 184,  210 => 203,  205 => 201,  178 => 13,  150 => 84,  146 => 82,  134 => 80,  152 => 6,  114 => 23,  110 => 83,  97 => 44,  126 => 28,  118 => 19,  77 => 17,  65 => 13,  58 => 11,  84 => 41,  23 => 2,  34 => 8,  129 => 46,  113 => 32,  70 => 14,  53 => 10,  20 => 1,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 40,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 25,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 204,  177 => 65,  169 => 60,  140 => 55,  132 => 71,  128 => 48,  107 => 22,  61 => 13,  273 => 96,  269 => 94,  254 => 24,  243 => 88,  240 => 86,  238 => 20,  235 => 74,  230 => 18,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 24,  208 => 21,  204 => 20,  179 => 69,  159 => 61,  143 => 57,  135 => 36,  119 => 86,  102 => 62,  71 => 70,  67 => 18,  63 => 15,  59 => 66,  87 => 57,  38 => 8,  26 => 2,  94 => 28,  89 => 31,  85 => 29,  75 => 21,  68 => 20,  56 => 13,  201 => 92,  196 => 18,  183 => 82,  171 => 111,  166 => 10,  163 => 62,  158 => 8,  156 => 66,  151 => 63,  142 => 82,  138 => 94,  136 => 93,  121 => 20,  117 => 67,  105 => 63,  91 => 32,  62 => 12,  49 => 14,  31 => 3,  28 => 2,  24 => 6,  25 => 3,  21 => 2,  19 => 1,  93 => 36,  88 => 42,  78 => 30,  46 => 7,  44 => 11,  27 => 4,  79 => 26,  72 => 20,  69 => 19,  47 => 8,  40 => 10,  37 => 10,  22 => 2,  246 => 22,  157 => 101,  145 => 46,  139 => 35,  131 => 90,  123 => 46,  120 => 68,  115 => 43,  111 => 22,  108 => 50,  101 => 80,  98 => 59,  96 => 26,  83 => 28,  74 => 16,  66 => 50,  55 => 9,  52 => 21,  50 => 44,  43 => 10,  41 => 5,  35 => 5,  32 => 3,  29 => 6,  209 => 82,  203 => 78,  199 => 198,  193 => 195,  189 => 71,  187 => 16,  182 => 66,  176 => 184,  173 => 183,  168 => 72,  164 => 43,  162 => 168,  154 => 38,  149 => 51,  147 => 40,  144 => 81,  141 => 48,  133 => 50,  130 => 32,  125 => 88,  122 => 29,  116 => 85,  112 => 42,  109 => 19,  106 => 18,  103 => 17,  99 => 31,  95 => 34,  92 => 27,  86 => 75,  82 => 16,  80 => 23,  73 => 19,  64 => 17,  60 => 16,  57 => 16,  54 => 12,  51 => 12,  48 => 13,  45 => 12,  42 => 8,  39 => 35,  36 => 4,  33 => 3,  30 => 1,);
    }
}
