<?php

/* WebProfilerBundle:Profiler:header.html.twig */
class __TwigTemplate_891ff86532e4d0addcbd9f1dfaf286a5034be89fb69bed9cb2489c06f6377307 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div id=\"header\" class=\"clear-fix\">
    <h1>
        <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAA+CAMAAAA/Mg/WAAAAjVBMVEXW1ta/v8Dh4eFgXmE8Oj7j4+PLy8unpqiPjpB4d3nIyMjX19dIRkro6OiYl5lUUlZsa22zsrTy8vLl5eU9Oz9KSEzs7OzBwcGEg4XLy8ybmpy9vb3ExMSxsbLa2tp+fH/Y2Nlxb3JXVVjPz89kYmWkpKXd3d3T09O+vr+LiYzMzMy6urowLjL////v7+/NfgWIAAAAL3RSTlP/////////////////////////////////////////////////////////////AFqlOPcAAAAJdnBBZwAAARMAAAA+AHci3fUAAAeMSURBVHja7Zvneuo4EIbdC65gOqGEEFIs+/4vbzWj5hLF5GySZxef7wcWtqVkXkYzIxmMWiNzu7btjJDMttdbsx6TPmQSbW3Skb2NxszERyB92f5Ymfgx0Sr2x8jEzMinis2xMXHXZFC5OyomXkZuUOyNiMnUITfJ8UfDxCc3yx8FE0TyFwpnopD8hdJm4jlkUOdjmh4XhMm8eyZuTIZ0LCrUfs4CbXTvTPJBHzlVVbogCwrlRFD2nTOZkgE9zqrqCM5SUV0IanvPTIZnzpmSeIbGpsHEce+ZSTCAZEG9ZDaXTESYDe+YiTuUc07gJnIOYQv1vwqziTGZPCWibVifMRl2k7SiOrP2/AJeoncUbxoE5hcXRD4ss356EXUoQYlRlpO6tsrS+JxJTHpaXC7z5sypCtKSJqJM4z8oXkJCfp5JsivLd+Olvo1JP+nMUyxFTm8Myx6rkluq2e2fTCoP8nrg/3SIYBRuZRJ+kHer2eZEXx7BTSrQEa/sU9JSXjdlwnTy6jr6UpwJYJgf1xOdN+gvllXcwKQTYS+iWF2ksyqFaCJyzSM9dqC4nUkQ1F9W+CuLp0lZyvYwE4+0VUD0kMXrHt9XMxFrN6Slad2Q/cVAonr915hsO8uaqmH5/FSdKnECZ9EraSn4mnWeaUbYiLDR72WanaTl0jO6sGlBPi0M45BwSy3auBoGfcULIuEuLct6KEuLCtpJi0lxgNvUgAkdz+iEk+eqmWXm+wr1LOqUCxHqL3ryxnuPtl3ejElYm8TxzJgQPO3Z2PDoWS7kErF/xQmgI/Qwo5yA1vSEI/c83YzEPFzW11UJmiAGamjyUDJzD7sSZSyBgBTSUExE/5UlBjSwk01a2lTtNDMTIXZx3MCxrbhVZ4Ch4uPPCNlKVFOwXvyhTOxLOFFEpKLad5o7vtAjdFQsD2U5tKaQuAm06NhNAMOuQCYvqxKZLCdgKF5ZFVomGHnLhwl0OvDcxECSrp+g3tRKR+n1TLrqhAaqMBJ5OcOGS40HCwHY1AyY0VPTd8A0WuHFtEsQTDEnO75pBg4UPrxHTE+Ar+Blp0bFFCBnwkwD55ggk135AO5fv9Omxa+sls14opjgCHA/HncJO4BjJV0mxwokPeKtQqVUj7yK0yceNySSSiTKFJ+eYBbaokKLXXY+bsaTjELE0TxH9ohdfkeIKKZ4WcA2EAloST/pKzDhAMB9CnaFQnnRMVnuAAUf6qUxYJcJThZVzL9i+0Q06gZVE13FmbIps+VTxwML8cAaPvcf0mDiqcF8YK1urKdIIeCTZ43j8k9ZVWRPyOTAkgw2UAk9qWNyxV6oXbmCUeC1zwQ9A1U0CL0OMOlR8dCynJkeMxQxuy6dq80kAMO5HIxAcrJEeGfE38eiv9FIHmANMAE3kQ0UJBwNkxf0LkGReUuPyTk9Yy3PdFThJB1m0n5MZLPVtotoAkAhcxKa1mdiq8SObdFD3Znh5PFk2WswawUFeHkQdk+6RX2fCZxryoJbr10mWKcqKK8qulxuZSJdIRIFag7tNhP7D5jIwLSGUXVMJv+WidVlsuEF65zXaSoLLTRENKu9DM004RN12ZQYZpIPMBEJLIYXlKFcf0mDqmKSqECDE+SgYfIODJS0TCqs1GbIhJ1CUFppy3U+831CfD0TfTwx+0yw0PHQWVSyYLoiDukeu3Y8KTRMREDqM8mI0CuAUNnm+YYQ69R9YSTxaubmOeVyExNP7aH4OG6fyZTyWKs1liFSL9ZeBmei3goGK13eKfgAfSa5iicycpz4hJmLAk4nW7PSjXm+sGH+DDPhR1WfBH0m6D9OTGJlgsilV9pKGkySVn1y0NZsDyoZFy0mAZHa81ItFbnmIkoVndZNFpG99k1zG8v1ckZkc5hJ5LCyNXAAzodM1vJPyjr2vaiX0HipGRO10Wgk9fKwAqu1TAqo8g60cD08lS0mZnvn9ZSmG+kb6VA48ZtMgu5yeStnFwZcPZPW41lE8iETj5c+KqPsSqb3mjNRUFCARM+kvkJ/VJtJTRpaPBdIYb9oVLF7opXbL9eIE5oisKh9bBOKW5QkxinZgADlBkglDlSPTpdYBmJuQvKOy1qjFkyEkqcdsrJqLRPQkq0aywejzSQnLc0vl0W7zn8kOmWaDRKh7Kt7z9hfK6zruyGxsBL9/sqwcHelt/foE50WvMjXaPDxaATB9vuklsSKyY/I+OSR11Ff2A/vz4tl4DdqC1PxN5hA7tRoj7FlTnQKP3USM//WZ8ou7r14v8QkIhrNBtzEHHhsA4n42+SwRPw7TLSO8jjgJvaAnxPnG5GYuFNb/xqTyGk9Bdzsz3Lq6JOOPqWoDffvFB3P7eaV5Y8xUdWWWBTPFiLrPBOt1nf+3a2ss832xgu2E9Eqdu+ciaqrN4LJEZDMB2bOPTOp/dazjM2cnGd40Go7gu8MB83alQZazMJ6haP4bnmovmqB2i9GikQxUVDmj+wB11iRKCZq+gwrHNFvmnzn7+8POBOlKCODyryx/UYyGHKVYIS/pXXDTyNJNM7fXEdrja84QGSMTFB+3seS++6If5uPMoPclmE1D8x6RPoHDj0oidWaaPMAAAAASUVORK5CYII=\" alt=\"Symfony profiler\">
    </h1>

    <div class=\"search\">
        <form method=\"get\" action=\"http://symfony.com/search\" target=\"_blank\">
            <div class=\"form-row\">
                <label for=\"search-id\">
                    <img src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAQAAAC1+jfqAAABUElEQVQoz2NgAIJ29iBdD0d7X2cPb+tY2f9MDMjgP2O2hKu7vS8CBlisZUNSMJ3fxRMkXO61wm2ue6I3iB1q8Z8ZriDZFCS03fm/wX+1/xp/TBo8QPxeqf+MUAW+QIFKj/+q/wX/c/3n/i/6Qd/bx943z/Q/K1SBI1D9fKv/AhCn/Wf5L5EHdFGKw39OqAIXoPpOMziX4T9/DFBBnuN/HqhAEtCKCNf/XDA/rZRyAmrpsvrPDVUw3wrkqCiLaewg6TohX1d7X0ffs5r/OaAKfinmgt3t4ulr4+Xg4ANip3j+l/zPArNT4LNOD0pAgWCSOUIBy3+h/+pXbBa5tni0eMx23+/mB1YSYnENroT5Pw/QSOX/mkCo+l/jgo0v2KJA643s8PgAmsMBDCbu/5xALHPB2husxN9uCzsDOgAq5kAoaZVnYMCh5Ky1r88Eh/+iABM8jUk7ClYIAAAAAElFTkSuQmCC\" alt=\"Search on Symfony website\">
                </label>

                <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"Search on Symfony website\">

                <button type=\"submit\" class=\"sf-button\">
                    <span class=\"border-l\">
                        <span class=\"border-r\">
                            <span class=\"btn-bg\">OK</span>
                        </span>
                    </span>
                </button>
            </div>
       </form>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:header.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  354 => 329,  1077 => 657,  1073 => 656,  1069 => 654,  1064 => 651,  1055 => 648,  1051 => 647,  1048 => 646,  1044 => 645,  1035 => 639,  1026 => 633,  1023 => 632,  1021 => 631,  1018 => 630,  1013 => 627,  1004 => 624,  1000 => 623,  997 => 622,  993 => 621,  984 => 615,  975 => 609,  972 => 608,  970 => 607,  967 => 606,  963 => 604,  959 => 602,  955 => 600,  947 => 597,  941 => 595,  937 => 593,  935 => 592,  930 => 590,  926 => 589,  923 => 588,  919 => 587,  911 => 581,  909 => 580,  905 => 579,  896 => 573,  893 => 572,  891 => 571,  888 => 570,  884 => 568,  880 => 566,  874 => 562,  870 => 560,  864 => 558,  862 => 557,  854 => 552,  848 => 548,  844 => 546,  838 => 544,  836 => 543,  830 => 539,  828 => 538,  824 => 537,  815 => 531,  812 => 530,  810 => 529,  807 => 528,  800 => 523,  796 => 521,  790 => 519,  780 => 513,  774 => 509,  770 => 507,  764 => 505,  762 => 504,  754 => 499,  740 => 491,  737 => 490,  732 => 487,  724 => 484,  718 => 482,  705 => 480,  696 => 476,  692 => 474,  676 => 467,  671 => 465,  668 => 464,  664 => 463,  655 => 457,  646 => 451,  642 => 449,  640 => 448,  636 => 446,  628 => 444,  626 => 443,  622 => 442,  603 => 439,  591 => 436,  587 => 434,  578 => 432,  574 => 431,  565 => 430,  559 => 427,  553 => 425,  551 => 424,  546 => 423,  542 => 421,  536 => 419,  534 => 418,  530 => 417,  527 => 416,  514 => 415,  297 => 200,  280 => 194,  251 => 182,  462 => 202,  449 => 198,  446 => 197,  441 => 196,  439 => 195,  431 => 189,  429 => 188,  422 => 184,  415 => 180,  408 => 176,  401 => 172,  394 => 168,  373 => 156,  351 => 328,  348 => 140,  342 => 137,  335 => 134,  329 => 131,  325 => 129,  323 => 128,  320 => 127,  300 => 121,  289 => 196,  286 => 112,  275 => 105,  270 => 102,  267 => 101,  256 => 96,  233 => 87,  226 => 84,  181 => 65,  417 => 143,  411 => 140,  405 => 137,  395 => 135,  388 => 134,  382 => 131,  377 => 129,  359 => 123,  356 => 330,  350 => 120,  347 => 119,  338 => 135,  333 => 115,  324 => 112,  313 => 110,  308 => 109,  249 => 181,  237 => 91,  207 => 75,  389 => 160,  386 => 159,  380 => 160,  378 => 157,  371 => 127,  367 => 155,  363 => 153,  361 => 146,  358 => 151,  353 => 121,  345 => 147,  343 => 146,  340 => 145,  334 => 141,  331 => 140,  328 => 113,  326 => 138,  321 => 135,  315 => 125,  307 => 287,  302 => 125,  296 => 121,  293 => 198,  290 => 119,  288 => 118,  281 => 98,  276 => 193,  274 => 96,  265 => 105,  259 => 103,  255 => 101,  253 => 100,  248 => 94,  213 => 78,  197 => 71,  194 => 70,  175 => 58,  172 => 62,  155 => 55,  806 => 488,  803 => 487,  792 => 485,  788 => 518,  784 => 482,  771 => 481,  745 => 493,  742 => 492,  723 => 472,  706 => 471,  702 => 479,  698 => 477,  694 => 467,  690 => 466,  686 => 472,  682 => 470,  678 => 468,  675 => 462,  673 => 461,  656 => 460,  645 => 458,  630 => 452,  625 => 450,  621 => 449,  618 => 448,  616 => 440,  602 => 445,  597 => 442,  563 => 429,  545 => 407,  528 => 406,  525 => 405,  523 => 404,  518 => 402,  513 => 400,  202 => 94,  191 => 69,  188 => 90,  185 => 66,  167 => 71,  153 => 56,  127 => 35,  124 => 46,  100 => 36,  160 => 42,  232 => 89,  184 => 63,  174 => 74,  170 => 56,  90 => 37,  81 => 23,  303 => 122,  271 => 190,  266 => 27,  262 => 188,  250 => 23,  242 => 21,  234 => 90,  225 => 17,  222 => 83,  216 => 79,  212 => 22,  200 => 72,  195 => 9,  192 => 17,  186 => 72,  180 => 70,  165 => 60,  161 => 58,  148 => 99,  76 => 27,  104 => 37,  231 => 184,  210 => 77,  205 => 201,  178 => 64,  150 => 55,  146 => 82,  134 => 47,  152 => 54,  114 => 36,  110 => 22,  97 => 41,  126 => 48,  118 => 49,  77 => 25,  65 => 11,  58 => 18,  84 => 27,  23 => 2,  34 => 5,  129 => 46,  113 => 40,  70 => 26,  53 => 15,  20 => 1,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 199,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 138,  402 => 130,  398 => 136,  393 => 126,  387 => 164,  384 => 132,  381 => 120,  379 => 119,  374 => 128,  368 => 340,  365 => 125,  362 => 124,  360 => 109,  355 => 143,  341 => 117,  337 => 103,  322 => 101,  314 => 99,  312 => 124,  309 => 288,  305 => 108,  298 => 120,  294 => 90,  285 => 100,  283 => 115,  278 => 106,  268 => 85,  264 => 84,  258 => 187,  252 => 80,  247 => 78,  241 => 90,  229 => 85,  220 => 81,  214 => 204,  177 => 69,  169 => 60,  140 => 55,  132 => 71,  128 => 42,  107 => 38,  61 => 23,  273 => 96,  269 => 107,  254 => 24,  243 => 88,  240 => 86,  238 => 20,  235 => 89,  230 => 18,  227 => 86,  224 => 71,  221 => 80,  219 => 76,  217 => 24,  208 => 76,  204 => 75,  179 => 69,  159 => 57,  143 => 57,  135 => 46,  119 => 40,  102 => 33,  71 => 23,  67 => 22,  63 => 21,  59 => 22,  87 => 32,  38 => 6,  26 => 3,  94 => 21,  89 => 30,  85 => 23,  75 => 28,  68 => 12,  56 => 11,  201 => 74,  196 => 92,  183 => 71,  171 => 73,  166 => 54,  163 => 53,  158 => 80,  156 => 58,  151 => 63,  142 => 82,  138 => 47,  136 => 71,  121 => 50,  117 => 37,  105 => 34,  91 => 35,  62 => 24,  49 => 11,  31 => 8,  28 => 3,  24 => 2,  25 => 35,  21 => 2,  19 => 1,  93 => 38,  88 => 24,  78 => 18,  46 => 14,  44 => 11,  27 => 3,  79 => 29,  72 => 27,  69 => 26,  47 => 15,  40 => 11,  37 => 7,  22 => 2,  246 => 93,  157 => 101,  145 => 74,  139 => 63,  131 => 61,  123 => 42,  120 => 38,  115 => 40,  111 => 47,  108 => 47,  101 => 43,  98 => 34,  96 => 30,  83 => 30,  74 => 27,  66 => 25,  55 => 15,  52 => 12,  50 => 15,  43 => 9,  41 => 8,  35 => 5,  32 => 6,  29 => 3,  209 => 82,  203 => 73,  199 => 93,  193 => 195,  189 => 66,  187 => 16,  182 => 87,  176 => 63,  173 => 85,  168 => 61,  164 => 70,  162 => 59,  154 => 38,  149 => 51,  147 => 54,  144 => 42,  141 => 51,  133 => 45,  130 => 46,  125 => 41,  122 => 29,  116 => 39,  112 => 40,  109 => 27,  106 => 51,  103 => 34,  99 => 31,  95 => 34,  92 => 28,  86 => 26,  82 => 21,  80 => 29,  73 => 23,  64 => 21,  60 => 20,  57 => 20,  54 => 19,  51 => 37,  48 => 9,  45 => 14,  42 => 8,  39 => 10,  36 => 8,  33 => 4,  30 => 5,);
    }
}
