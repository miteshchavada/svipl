<?php

/* AcmeDemoBundle:Welcome:index.html.twig */
class __TwigTemplate_056e12c9da58289a1461f9eb0c52dd4aa2833a226909405f9adcf955b901d816 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("AcmeDemoBundle::layout.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content_header' => array($this, 'block_content_header'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "AcmeDemoBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Symfony - Welcome";
    }

    // line 5
    public function block_content_header($context, array $blocks = array())
    {
        echo "";
    }

    // line 7
    public function block_content($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        $context["version"] = ((twig_constant("Symfony\\Component\\HttpKernel\\Kernel::MAJOR_VERSION") . ".") . twig_constant("Symfony\\Component\\HttpKernel\\Kernel::MINOR_VERSION"));
        // line 9
        echo "
    <h1 class=\"title\">Welcome!</h1>

    <p>Congratulations! You have successfully installed a new Symfony application.</p>

    <div class=\"symfony-blocks-welcome\">
        <div class=\"block-quick-tour\">
            <div class=\"illustration\">
                <img src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/images/welcome-quick-tour.gif"), "html", null, true);
        echo "\" alt=\"Quick tour\" />
            </div>
            <a href=\"http://symfony.com/doc/";
        // line 19
        echo twig_escape_filter($this->env, $this->getContext($context, "version"), "html", null, true);
        echo "/quick_tour/index.html\" class=\"sf-button sf-button-selected\">
                <span class=\"border-l\">
                    <span class=\"border-r\">
                        <span class=\"btn-bg\">Read the Quick Tour</span>
                    </span>
                </span>
            </a>
        </div>
        ";
        // line 27
        if (($this->getAttribute($this->getContext($context, "app"), "environment") == "dev")) {
            // line 28
            echo "            <div class=\"block-configure\">
                <div class=\"illustration\">
                    <img src=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/images/welcome-configure.gif"), "html", null, true);
            echo "\" alt=\"Configure your application\" />
                </div>
                <a href=\"";
            // line 32
            echo $this->env->getExtension('routing')->getPath("_configurator_home");
            echo "\" class=\"sf-button sf-button-selected\">
                    <span class=\"border-l\">
                        <span class=\"border-r\">
                            <span class=\"btn-bg\">Configure</span>
                        </span>
                    </span>
                </a>
            </div>
        ";
        }
        // line 41
        echo "        <div class=\"block-demo\">
            <div class=\"illustration\">
                <img src=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmedemo/images/welcome-demo.gif"), "html", null, true);
        echo "\" alt=\"Demo\" />
            </div>
            <a href=\"";
        // line 45
        echo $this->env->getExtension('routing')->getPath("_demo");
        echo "\" class=\"sf-button sf-button-selected\">
                <span class=\"border-l\">
                    <span class=\"border-r\">
                        <span class=\"btn-bg\">Run The Demo</span>
                    </span>
                </span>
            </a>
        </div>
    </div>

    <div class=\"symfony-blocks-help\">
        <div class=\"block-documentation\">
            <ul>
                <li><strong>Documentation</strong></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 59
        echo twig_escape_filter($this->env, $this->getContext($context, "version"), "html", null, true);
        echo "/book/index.html\">The Book</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 60
        echo twig_escape_filter($this->env, $this->getContext($context, "version"), "html", null, true);
        echo "/cookbook/index.html\">The Cookbook</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 61
        echo twig_escape_filter($this->env, $this->getContext($context, "version"), "html", null, true);
        echo "/components/index.html\">The Components</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 62
        echo twig_escape_filter($this->env, $this->getContext($context, "version"), "html", null, true);
        echo "/reference/index.html\">Reference</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 63
        echo twig_escape_filter($this->env, $this->getContext($context, "version"), "html", null, true);
        echo "/glossary.html\">Glossary</a></li>
            </ul>
        </div>
        <div class=\"block-documentation-more\">
            <ul>
                <li><strong>Sensio</strong></li>
                <li><a href=\"http://trainings.sensiolabs.com\">Trainings</a></li>
                <li><a href=\"http://books.sensiolabs.com\">Books</a></li>
            </ul>
        </div>
        <div class=\"block-community\">
            <ul>
                <li><strong>Community</strong></li>
                <li><a href=\"http://symfony.com/irc\">IRC channel</a></li>
                <li><a href=\"http://symfony.com/mailing-lists\">Mailing lists</a></li>
                <li><a href=\"http://forum.symfony-project.org\">Forum</a></li>
                <li><a href=\"http://symfony.com/doc/";
        // line 79
        echo twig_escape_filter($this->env, $this->getContext($context, "version"), "html", null, true);
        echo "/contributing/index.html\">Contributing</a></li>
            </ul>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Welcome:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 60,  124 => 46,  100 => 32,  160 => 42,  232 => 81,  184 => 15,  174 => 12,  170 => 11,  90 => 32,  81 => 22,  303 => 116,  271 => 29,  266 => 27,  262 => 26,  250 => 23,  242 => 21,  234 => 19,  225 => 17,  222 => 16,  216 => 14,  212 => 22,  200 => 19,  195 => 9,  192 => 17,  186 => 6,  180 => 117,  165 => 50,  161 => 9,  148 => 99,  76 => 28,  104 => 37,  231 => 184,  210 => 203,  205 => 201,  178 => 13,  150 => 84,  146 => 82,  134 => 45,  152 => 6,  114 => 40,  110 => 22,  97 => 41,  126 => 48,  118 => 19,  77 => 17,  65 => 16,  58 => 17,  84 => 29,  23 => 2,  34 => 8,  129 => 46,  113 => 40,  70 => 17,  53 => 10,  20 => 1,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 40,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 25,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 204,  177 => 65,  169 => 60,  140 => 55,  132 => 71,  128 => 43,  107 => 38,  61 => 12,  273 => 96,  269 => 94,  254 => 24,  243 => 88,  240 => 86,  238 => 20,  235 => 74,  230 => 18,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 24,  208 => 21,  204 => 20,  179 => 69,  159 => 61,  143 => 57,  135 => 62,  119 => 86,  102 => 17,  71 => 19,  67 => 16,  63 => 19,  59 => 13,  87 => 57,  38 => 6,  26 => 9,  94 => 34,  89 => 33,  85 => 32,  75 => 21,  68 => 32,  56 => 11,  201 => 92,  196 => 18,  183 => 82,  171 => 111,  166 => 10,  163 => 62,  158 => 79,  156 => 66,  151 => 63,  142 => 82,  138 => 94,  136 => 93,  121 => 20,  117 => 19,  105 => 18,  91 => 28,  62 => 15,  49 => 10,  31 => 3,  28 => 2,  24 => 6,  25 => 4,  21 => 2,  19 => 1,  93 => 28,  88 => 31,  78 => 26,  46 => 10,  44 => 11,  27 => 5,  79 => 22,  72 => 32,  69 => 19,  47 => 8,  40 => 6,  37 => 5,  22 => 2,  246 => 22,  157 => 101,  145 => 46,  139 => 63,  131 => 61,  123 => 59,  120 => 20,  115 => 40,  111 => 22,  108 => 19,  101 => 43,  98 => 32,  96 => 36,  83 => 31,  74 => 27,  66 => 30,  55 => 14,  52 => 10,  50 => 13,  43 => 7,  41 => 5,  35 => 5,  32 => 6,  29 => 3,  209 => 82,  203 => 78,  199 => 198,  193 => 195,  189 => 71,  187 => 16,  182 => 66,  176 => 184,  173 => 183,  168 => 72,  164 => 43,  162 => 168,  154 => 38,  149 => 51,  147 => 40,  144 => 81,  141 => 48,  133 => 50,  130 => 45,  125 => 42,  122 => 29,  116 => 40,  112 => 40,  109 => 40,  106 => 45,  103 => 34,  99 => 34,  95 => 34,  92 => 35,  86 => 26,  82 => 28,  80 => 30,  73 => 16,  64 => 13,  60 => 15,  57 => 12,  54 => 12,  51 => 12,  48 => 9,  45 => 8,  42 => 7,  39 => 4,  36 => 5,  33 => 3,  30 => 3,);
    }
}
