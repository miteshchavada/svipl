<?php

/* AcmeInfoBundle:Newslist:index.html.twig */
class __TwigTemplate_e91b6028ce5b5b1aee4d3bd60a507ff2e4753d065691373ada11831d26a32c8c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        $this->displayBlock('content', $context, $blocks);
    }

    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <h1 class=\"page-header\">News List</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <div class=\"panel panel-default\">
                        <div class=\"panel-heading\">
                            News List
\t\t\t\t<div style=\"float:right; margin-top:-15px;\" class=\"panel-heading\"><a href=\"news/add\"><button type=\"button\" class=\"btn btn-primary btn-sm\">Add News</button></a></div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class=\"panel-body\">
                            <div class=\"table-responsive\">
                                <table class=\"table table-striped table-bordered table-hover\" id=\"dataTables-example\">
                                    <thead>
                                        <tr>
                                            <th>Serial No</th>
                                            <th>Title</th>
\t\t\t\t\t    <th>Image</th>
                                            <th>Description</th>
                                            <th>Operations</th>
                                        </tr>
                                    </thead>
                                    <tbody>
\t\t\t\t\t";
        // line 32
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "news"));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 33
            echo "                                         <tr class=\"gradeA\">
                                            <td>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "loop"), "index"), "html", null, true);
            echo "</td>
                                            <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "title"), "html", null, true);
            echo "</td>
                                            <td><img src=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/news/", 1 => $this->getAttribute($this->getContext($context, "product"), "id"), 2 => "/", 3 => $this->getAttribute($this->getContext($context, "product"), "image")))), "html", null, true);
            echo "\" style=\"width:80px; height: 50px;\" /></td>
                                            <td width=\"250px;\">";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "description"), "html", null, true);
            echo "</td>
                                            <td>
\t\t\t\t\t\t<a href=\"news/edit?id=";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "id"), "html", null, true);
            echo "\" class=\"btn btn-primary\">edit</a>
        \t\t\t\t\t<a href=\"news/delete?id=";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "product"), "id"), "html", null, true);
            echo "\" class=\"btn btn-danger\" onclick=\"return confirm('are sure delete?')\">delete</a></li>
\t\t\t\t\t    </td>
                                        </tr>
\t\t\t\t\t";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "                                    </tbody>
\t\t\t\t    <!-- div>";
        // line 45
        echo $this->getContext($context, "paginator");
        echo "</div--> 
                                </table>
                            </div>
                    </div>
                </div>
            </div>
";
    }

    public function getTemplateName()
    {
        return "AcmeInfoBundle:Newslist:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 44,  124 => 46,  100 => 37,  160 => 42,  232 => 81,  184 => 15,  174 => 12,  170 => 11,  90 => 33,  81 => 22,  303 => 116,  271 => 29,  266 => 27,  262 => 26,  250 => 23,  242 => 21,  234 => 19,  225 => 17,  222 => 16,  216 => 14,  212 => 22,  200 => 19,  195 => 9,  192 => 17,  186 => 6,  180 => 117,  165 => 50,  161 => 9,  148 => 99,  76 => 20,  104 => 37,  231 => 184,  210 => 203,  205 => 201,  178 => 13,  150 => 84,  146 => 82,  134 => 45,  152 => 6,  114 => 40,  110 => 38,  97 => 44,  126 => 28,  118 => 19,  77 => 17,  65 => 16,  58 => 15,  84 => 23,  23 => 2,  34 => 8,  129 => 46,  113 => 40,  70 => 17,  53 => 10,  20 => 1,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 40,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 25,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 204,  177 => 65,  169 => 60,  140 => 55,  132 => 71,  128 => 43,  107 => 38,  61 => 15,  273 => 96,  269 => 94,  254 => 24,  243 => 88,  240 => 86,  238 => 20,  235 => 74,  230 => 18,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 24,  208 => 21,  204 => 20,  179 => 69,  159 => 61,  143 => 57,  135 => 36,  119 => 86,  102 => 62,  71 => 19,  67 => 16,  63 => 15,  59 => 14,  87 => 57,  38 => 4,  26 => 2,  94 => 34,  89 => 33,  85 => 33,  75 => 21,  68 => 32,  56 => 13,  201 => 92,  196 => 18,  183 => 82,  171 => 111,  166 => 10,  163 => 62,  158 => 8,  156 => 66,  151 => 63,  142 => 82,  138 => 94,  136 => 93,  121 => 20,  117 => 67,  105 => 39,  91 => 28,  62 => 15,  49 => 14,  31 => 3,  28 => 2,  24 => 6,  25 => 3,  21 => 2,  19 => 1,  93 => 28,  88 => 34,  78 => 30,  46 => 7,  44 => 11,  27 => 4,  79 => 22,  72 => 32,  69 => 19,  47 => 8,  40 => 10,  37 => 10,  22 => 2,  246 => 22,  157 => 101,  145 => 46,  139 => 35,  131 => 44,  123 => 46,  120 => 68,  115 => 40,  111 => 22,  108 => 39,  101 => 80,  98 => 32,  96 => 36,  83 => 31,  74 => 20,  66 => 30,  55 => 9,  52 => 12,  50 => 13,  43 => 10,  41 => 4,  35 => 3,  32 => 3,  29 => 2,  209 => 82,  203 => 78,  199 => 198,  193 => 195,  189 => 71,  187 => 16,  182 => 66,  176 => 184,  173 => 183,  168 => 72,  164 => 43,  162 => 168,  154 => 38,  149 => 51,  147 => 40,  144 => 81,  141 => 48,  133 => 50,  130 => 45,  125 => 42,  122 => 29,  116 => 40,  112 => 42,  109 => 40,  106 => 18,  103 => 34,  99 => 34,  95 => 34,  92 => 35,  86 => 26,  82 => 16,  80 => 23,  73 => 19,  64 => 16,  60 => 15,  57 => 14,  54 => 12,  51 => 12,  48 => 11,  45 => 12,  42 => 4,  39 => 4,  36 => 4,  33 => 3,  30 => 1,);
    }
}
