<?php

/* ::front.html.twig */
class __TwigTemplate_ea72b099456aafc388c8c61810445a668c05ad87ef8715b6217f5b90afc7a363 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 54
        echo "    </head>
    <body id=\"page1\">
        <div id=\"sidebar\">
            <div class=\"body1\">
                <div class=\"body2\">
                    <div class=\"main zerogrid\">
                        <header>
                            <div class=\"wrapper row\">
                                <h1><a href=\"";
        // line 62
        echo $this->env->getExtension('routing')->getPath("acme_home");
        echo "\" id=\"logo\"><img src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/images/logo.png"), "html", null, true);
        echo "\" /></a></h1>
                                <nav>
                                    <ul id=\"menu\">
                                        ";
        // line 65
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "acme_home")) {
            // line 66
            echo "                                            <li id=\"nav1\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        } else {
            // line 68
            echo "                                            <li id=\"nav1\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("acme_home");
            echo "\">Home<span>Welcome!</span></a></li>
                                            ";
        }
        // line 70
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "news")) {
            // line 71
            echo "                                            <li id=\"nav2\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        } else {
            // line 73
            echo "                                            <li id=\"nav2\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("news");
            echo "\">News<span>Fresh</span></a></li>
                                            ";
        }
        // line 75
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "services")) {
            // line 76
            echo "                                            <li id=\"nav3\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        } else {
            // line 78
            echo "                                            <li id=\"nav3\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("services");
            echo "\">Services<span>for you</span></a></li>
                                            ";
        }
        // line 80
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "products")) {
            // line 81
            echo "                                            <li id=\"nav4\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        } else {
            // line 83
            echo "                                            <li id=\"nav4\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("products");
            echo "\">Products<span>The best</span></a></li>
                                            ";
        }
        // line 85
        echo "                                            ";
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "contact")) {
            // line 86
            echo "                                            <li id=\"nav5\" class=\"active\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        } else {
            // line 88
            echo "                                            <li id=\"nav5\"><a href=\"";
            echo $this->env->getExtension('routing')->getPath("contact");
            echo "\">Contacts<span>Our Address</span></a></li>
                                            ";
        }
        // line 90
        echo "                                    </ul>
                                </nav>
                            </div>
                            ";
        // line 93
        if (($this->getAttribute($this->getAttribute($this->getContext($context, "app"), "request"), "get", array(0 => "_route"), "method") == "acme_home")) {
            // line 94
            echo "                                <div class=\"wrapper row\">\t\t\t\t\t\t\t
                                    <div class=\"slider\">\t\t\t\t\t\t\t
                                        <div class=\"rslides_container\">
                                            <ul class=\"rslides\" id=\"slider\">
                                                ";
            // line 98
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable($this->getContext($context, "images"));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                // line 99
                echo "                                                    <li><img src=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/", 1 => $this->getAttribute($this->getContext($context, "image"), "image")))), "html", null, true);
                echo "\" alt=\"\"></li>
                                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 101
            echo "                                            </ul>
                                        </div>
                                    </div>\t\t\t\t\t\t\t
                                </div>
                            ";
        } else {
            // line 106
            echo "                                <div class=\"wrapper row\">
                                    <div class=\"slider\">
                                    </div>
                                </div>
                            ";
        }
        // line 111
        echo "                        </header>
                    </div>
                </div>
            </div>
        </div>
    ";
        // line 116
        $this->displayBlock('body', $context, $blocks);
        // line 117
        echo "</body>
</html>
";
    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        echo "Test Application";
    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 9
        echo "            <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/reset.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/layout.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/zerogrid.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/responsive.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
            <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/css/responsiveslides.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        ";
    }

    // line 16
    public function block_javascripts($context, array $blocks = array())
    {
        // line 17
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jquery-1.6.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-yui.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/cufon-replace.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_400.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/Swis721_Cn_BT_700.font.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jquery.easing.1.3.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/tms-0.3.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/tms_presets.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/jcarousellite.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/script.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/css3-mediaqueries.js"), "html", null, true);
        echo "\"></script>
            <!--[if lt IE 9]>
                  <script type=\"text/javascript\" src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/html5.js"), "html", null, true);
        echo "\"></script>
                  <style type=\"text/css\">
                          .bg{ behavior: url(js/PIE.htc); }
                  </style>
            <![endif]-->
            <!--[if lt IE 7]>
                    <div style=' clear: both; text-align:center; position: relative;'>
                            <a href=\"http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode\"><img src=\"http://www.theie6countdown.com/images/upgrade.jpg\" border=\"0\"  alt=\"\" /></a>
                    </div>
            <![endif]-->

            <script src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/acmehome/js/responsiveslides.js"), "html", null, true);
        echo "\"></script>
            <script>
                \$(function () {
                    \$(\"#slider\").responsiveSlides({
                        auto: true,
                        pager: false,
                        nav: true,
                        speed: 500,
                        maxwidth: 960,
                        namespace: \"centered-btns\"
                    });
                });
            </script>
        ";
    }

    // line 116
    public function block_body($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::front.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  303 => 116,  285 => 40,  271 => 29,  266 => 27,  262 => 26,  258 => 25,  254 => 24,  250 => 23,  246 => 22,  242 => 21,  238 => 20,  234 => 19,  230 => 18,  225 => 17,  222 => 16,  216 => 14,  212 => 13,  208 => 12,  204 => 11,  200 => 10,  195 => 9,  192 => 8,  186 => 6,  180 => 117,  178 => 116,  171 => 111,  164 => 106,  157 => 101,  144 => 98,  138 => 94,  136 => 93,  131 => 90,  125 => 88,  119 => 86,  116 => 85,  110 => 83,  104 => 81,  95 => 78,  89 => 76,  86 => 75,  80 => 73,  74 => 71,  57 => 65,  49 => 62,  39 => 54,  36 => 16,  34 => 8,  29 => 6,  23 => 2,  165 => 50,  161 => 49,  148 => 99,  139 => 35,  135 => 34,  130 => 32,  126 => 30,  122 => 29,  114 => 23,  105 => 21,  101 => 80,  97 => 18,  77 => 14,  71 => 70,  65 => 68,  59 => 66,  55 => 9,  38 => 8,  31 => 3,  28 => 2,);
    }
}
