<?php

/* AcmeImageBundle:Default:add.html.twig */
class __TwigTemplate_a97f39769ae887ee13b7b9767dc58a45a426d16424e4390e572ae074a0b033b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        $this->displayBlock('content', $context, $blocks);
    }

    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1 class=\"page-header\">Image Add Form</h1>
        </div>
    </div>
    <div class=\"row\">
                <center>
                <form action=\"";
        // line 11
        echo $this->env->getExtension('routing')->getPath("acme_image_add");
        echo "\" method=\"post\" ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getContext($context, "form"), 'enctype');
        echo " class=\"form-group\">
                    ";
        // line 12
        if ((!$this->getAttribute($this->getAttribute($this->getContext($context, "form"), "vars"), "valid"))) {
            // line 13
            echo "                                <div class=\"alert alert-danger\">    
                    ";
            // line 14
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "image"), 'errors');
            echo "
                    </div>
                    ";
        }
        // line 17
        echo "                    <div class=\"form-group col-lg-12\">
                        ";
        // line 18
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "image"), 'label', array("label_attr" => array("class" => "control-label col-sm-2"), "label" => "Image: "));
        echo "
                        <div class=\"col-sm-2\">
                        ";
        // line 20
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getContext($context, "form"), "image"), 'widget', array("attr" => array("class" => "btn btn-default btn-file")));
        echo "
                        </div>
                    </div>
                    <div class=\"form-group col-lg-6\">
                        <input type=\"submit\" formnovalidate value=\"Insert\" name=\"insert\" class=\"btn btn-primary\"/>
                        <input type=\"reset\" name=\"Reset\" value=\"Reset\" class=\"btn btn-danger\" onclick=\"javascript:window.location.href='";
        // line 25
        echo $this->env->getExtension('routing')->getPath("acme_image");
        echo "'\"/>
                    </div>
                </form>
                </center>        
        </div>
";
    }

    public function getTemplateName()
    {
        return "AcmeImageBundle:Default:add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 25,  104 => 33,  231 => 184,  210 => 203,  205 => 201,  178 => 185,  150 => 84,  146 => 83,  134 => 80,  152 => 51,  114 => 66,  110 => 41,  97 => 37,  126 => 43,  118 => 43,  77 => 20,  65 => 13,  58 => 14,  84 => 33,  23 => 3,  34 => 5,  129 => 46,  113 => 41,  70 => 26,  53 => 12,  20 => 1,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 89,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 81,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 204,  177 => 65,  169 => 60,  140 => 55,  132 => 51,  128 => 48,  107 => 37,  61 => 13,  273 => 96,  269 => 94,  254 => 92,  243 => 88,  240 => 86,  238 => 85,  235 => 74,  230 => 82,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 75,  208 => 68,  204 => 72,  179 => 69,  159 => 61,  143 => 57,  135 => 52,  119 => 42,  102 => 32,  71 => 23,  67 => 18,  63 => 15,  59 => 17,  87 => 32,  38 => 4,  26 => 2,  94 => 28,  89 => 35,  85 => 31,  75 => 17,  68 => 14,  56 => 13,  201 => 92,  196 => 90,  183 => 82,  171 => 61,  166 => 71,  163 => 62,  158 => 86,  156 => 66,  151 => 63,  142 => 82,  138 => 81,  136 => 48,  121 => 41,  117 => 43,  105 => 39,  91 => 32,  62 => 12,  49 => 13,  31 => 4,  28 => 3,  24 => 6,  25 => 3,  21 => 2,  19 => 1,  93 => 36,  88 => 6,  78 => 30,  46 => 7,  44 => 12,  27 => 4,  79 => 26,  72 => 20,  69 => 33,  47 => 11,  40 => 16,  37 => 10,  22 => 2,  246 => 90,  157 => 56,  145 => 46,  139 => 45,  131 => 52,  123 => 46,  120 => 44,  115 => 43,  111 => 22,  108 => 63,  101 => 38,  98 => 59,  96 => 31,  83 => 28,  74 => 16,  66 => 15,  55 => 13,  52 => 21,  50 => 8,  43 => 8,  41 => 5,  35 => 5,  32 => 3,  29 => 2,  209 => 82,  203 => 78,  199 => 198,  193 => 195,  189 => 71,  187 => 192,  182 => 66,  176 => 184,  173 => 183,  168 => 72,  164 => 59,  162 => 168,  154 => 85,  149 => 51,  147 => 40,  144 => 39,  141 => 48,  133 => 50,  130 => 79,  125 => 44,  122 => 43,  116 => 39,  112 => 42,  109 => 40,  106 => 18,  103 => 61,  99 => 31,  95 => 34,  92 => 27,  86 => 34,  82 => 31,  80 => 25,  73 => 19,  64 => 17,  60 => 18,  57 => 24,  54 => 12,  51 => 21,  48 => 12,  45 => 18,  42 => 8,  39 => 4,  36 => 15,  33 => 3,  30 => 1,);
    }
}
