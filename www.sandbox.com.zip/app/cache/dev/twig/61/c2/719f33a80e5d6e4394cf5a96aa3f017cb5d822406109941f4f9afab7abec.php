<?php

/* AcmeHomeBundle:Default:news.html.twig */
class __TwigTemplate_61c2719f33a80e5d6e4394cf5a96aa3f017cb5d822406109941f4f9afab7abec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::common.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::common.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "    <div class=\"body3\">
        <div class=\"main zerogrid\">
            <!-- content -->
            <article id=\"content\">
                <div class=\"wrapper tabs\">
                    ";
        // line 8
        $context["i"] = 0;
        // line 9
        echo "                    ";
        $context["divNo"] = 1;
        // line 10
        echo "                    ";
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getContext($context, "news"));
        foreach ($context['_seq'] as $context["_key"] => $context["new"]) {
            // line 11
            echo "
                        ";
            // line 12
            if (((($this->getContext($context, "i") % 3) == 0) && ($this->getContext($context, "divNo") != 1))) {
                // line 13
                echo "                        </div>
                    ";
            }
            // line 15
            echo "
                    ";
            // line 16
            if ((($this->getContext($context, "i") % 3) == 0)) {
                // line 17
                echo "                        <div class=\"tab-content\" id=\"tab";
                echo twig_escape_filter($this->env, $this->getContext($context, "divNo"), "html", null, true);
                echo "\">
                            ";
                // line 18
                $context["divNo"] = ($this->getContext($context, "divNo") + 1);
                // line 19
                echo "                        ";
            }
            // line 20
            echo "
                        <h5><span class=\"dropcap\"><strong>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "</strong><span>06</span></span>Lorem ipsum dolor sit amet consectetur adipisicing elit</h5>
                        <div class=\"wrapper pad_bot2\">
                            <figure class=\"left marg_right1\"><img src=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl(twig_join_filter(array(0 => "uploads/news/", 1 => $this->getAttribute($this->getContext($context, "new"), "id"), 2 => "/", 3 => $this->getAttribute($this->getContext($context, "new"), "image")))), "html", null, true);
            echo "\" alt=\"\"></figure>
                            <p class=\"pad_bot1\" id=\"desc_";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "\" style=\"display:block;\">";
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($this->getContext($context, "new"), "description"), 0, 200), "html", null, true);
            echo "</p>
                            <p class=\"pad_bot1\" id=\"pname_";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "\" style=\"display:none;\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "description"), "html", null, true);
            echo "</p>
                            <a href=\"Javascript:toggle('pname_";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "','desc_";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "new"), "id"), "html", null, true);
            echo "');\" class=\"link1\">Read More</a>
                        </div>

                        ";
            // line 29
            $context["i"] = ($this->getContext($context, "i") + 1);
            // line 30
            echo "
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['new'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                </div>

                <ul class=\"nav\">
                    ";
        // line 35
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable(range(1, twig_round(($this->getContext($context, "count") / 3), 0, "ceil")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["j"]) {
            // line 36
            echo "                        <li class=\"selected\"><a href=\"#tab";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "loop"), "index"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getContext($context, "loop"), "index"), "html", null, true);
            echo "</a></li>
                        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['j'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        echo "                </ul>
            </article>    
        </div>
    </div>            
    ";
        // line 42
        echo twig_include($this->env, $context, "followUs.html.twig");
        echo "
    ";
        // line 43
        echo twig_include($this->env, $context, "footer.html.twig");
        echo "                                      
    <script type=\"text/javascript\"> Cufon.now();</script>
    <script>
        \$(document).ready(function () {
            tabs.init();
        })
    </script>
    <script type=\"text/javascript\">
        function toggle(obj, obj1) {

            var toggle = document.getElementById(obj);
            var desc = document.getElementById(obj1);

            if (toggle.style.display != \"none\") {
                toggle.style.display = \"none\";
                desc.style.display = \"block\";
            }
            else {
                toggle.style.display = \"block\";
                desc.style.display = \"none\";
            }
        }
    </script>
";
    }

    public function getTemplateName()
    {
        return "AcmeHomeBundle:Default:news.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  160 => 42,  232 => 81,  184 => 15,  174 => 12,  170 => 11,  90 => 25,  81 => 55,  303 => 116,  271 => 29,  266 => 27,  262 => 26,  250 => 23,  242 => 21,  234 => 19,  225 => 17,  222 => 16,  216 => 14,  212 => 22,  200 => 19,  195 => 9,  192 => 17,  186 => 6,  180 => 117,  165 => 50,  161 => 9,  148 => 99,  76 => 15,  104 => 29,  231 => 184,  210 => 203,  205 => 201,  178 => 13,  150 => 84,  146 => 82,  134 => 80,  152 => 6,  114 => 23,  110 => 83,  97 => 18,  126 => 70,  118 => 35,  77 => 14,  65 => 68,  58 => 47,  84 => 24,  23 => 2,  34 => 8,  129 => 46,  113 => 32,  70 => 14,  53 => 13,  20 => 1,  480 => 162,  474 => 161,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 147,  435 => 146,  430 => 144,  427 => 143,  423 => 142,  413 => 134,  409 => 132,  407 => 131,  402 => 130,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 120,  379 => 119,  374 => 116,  368 => 112,  365 => 111,  362 => 110,  360 => 109,  355 => 106,  341 => 105,  337 => 103,  322 => 101,  314 => 99,  312 => 98,  309 => 97,  305 => 95,  298 => 91,  294 => 90,  285 => 40,  283 => 88,  278 => 86,  268 => 85,  264 => 84,  258 => 25,  252 => 80,  247 => 78,  241 => 77,  229 => 73,  220 => 70,  214 => 204,  177 => 65,  169 => 60,  140 => 55,  132 => 71,  128 => 48,  107 => 22,  61 => 13,  273 => 96,  269 => 94,  254 => 24,  243 => 88,  240 => 86,  238 => 20,  235 => 74,  230 => 18,  227 => 81,  224 => 71,  221 => 77,  219 => 76,  217 => 24,  208 => 21,  204 => 20,  179 => 69,  159 => 61,  143 => 57,  135 => 36,  119 => 86,  102 => 62,  71 => 70,  67 => 18,  63 => 15,  59 => 66,  87 => 57,  38 => 8,  26 => 2,  94 => 28,  89 => 76,  85 => 31,  75 => 21,  68 => 14,  56 => 13,  201 => 92,  196 => 18,  183 => 82,  171 => 111,  166 => 10,  163 => 62,  158 => 8,  156 => 66,  151 => 63,  142 => 82,  138 => 94,  136 => 93,  121 => 41,  117 => 67,  105 => 63,  91 => 32,  62 => 17,  49 => 62,  31 => 3,  28 => 2,  24 => 6,  25 => 3,  21 => 2,  19 => 1,  93 => 36,  88 => 17,  78 => 30,  46 => 7,  44 => 12,  27 => 4,  79 => 26,  72 => 20,  69 => 19,  47 => 11,  40 => 9,  37 => 10,  22 => 2,  246 => 22,  157 => 101,  145 => 46,  139 => 35,  131 => 90,  123 => 46,  120 => 68,  115 => 43,  111 => 65,  108 => 63,  101 => 80,  98 => 59,  96 => 26,  83 => 28,  74 => 71,  66 => 50,  55 => 9,  52 => 21,  50 => 44,  43 => 10,  41 => 5,  35 => 5,  32 => 3,  29 => 6,  209 => 82,  203 => 78,  199 => 198,  193 => 195,  189 => 71,  187 => 16,  182 => 66,  176 => 184,  173 => 183,  168 => 72,  164 => 43,  162 => 168,  154 => 38,  149 => 51,  147 => 40,  144 => 81,  141 => 48,  133 => 50,  130 => 32,  125 => 88,  122 => 29,  116 => 85,  112 => 42,  109 => 40,  106 => 30,  103 => 61,  99 => 31,  95 => 78,  92 => 27,  86 => 75,  82 => 16,  80 => 23,  73 => 19,  64 => 17,  60 => 16,  57 => 15,  54 => 12,  51 => 12,  48 => 11,  45 => 18,  42 => 8,  39 => 35,  36 => 15,  33 => 3,  30 => 1,);
    }
}
