<?php

namespace Acme\ImageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AcmeImageBundle extends Bundle
{
}
