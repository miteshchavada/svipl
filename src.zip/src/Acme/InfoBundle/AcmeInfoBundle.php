<?php

namespace Acme\InfoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AcmeInfoBundle extends Bundle
{
}
