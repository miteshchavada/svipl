<?php

namespace Acme\HomeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AcmeHomeBundle extends Bundle
{
}
